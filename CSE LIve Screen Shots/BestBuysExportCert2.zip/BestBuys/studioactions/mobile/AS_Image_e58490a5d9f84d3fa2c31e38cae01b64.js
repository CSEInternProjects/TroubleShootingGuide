function AS_Image_e58490a5d9f84d3fa2c31e38cae01b64(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}