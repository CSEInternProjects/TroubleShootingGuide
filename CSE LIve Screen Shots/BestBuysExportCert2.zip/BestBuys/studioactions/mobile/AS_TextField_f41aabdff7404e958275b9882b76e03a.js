function AS_TextField_f41aabdff7404e958275b9882b76e03a(eventobject, changedtext) {
    searchNow("Cats");
}