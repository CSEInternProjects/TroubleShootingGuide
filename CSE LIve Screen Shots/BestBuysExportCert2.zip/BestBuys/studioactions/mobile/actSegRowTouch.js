function actSegRowTouch(eventobject, sectionNumber, rowNumber) {
    return AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber);
}

function AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber) {
    return segRowTouch.call(this);
}