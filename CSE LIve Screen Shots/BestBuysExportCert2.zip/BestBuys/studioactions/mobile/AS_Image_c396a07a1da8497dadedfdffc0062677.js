function AS_Image_c396a07a1da8497dadedfdffc0062677(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}