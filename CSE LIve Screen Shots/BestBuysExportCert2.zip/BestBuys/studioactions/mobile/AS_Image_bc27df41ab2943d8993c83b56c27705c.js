function AS_Image_bc27df41ab2943d8993c83b56c27705c(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.forceLayout();
}