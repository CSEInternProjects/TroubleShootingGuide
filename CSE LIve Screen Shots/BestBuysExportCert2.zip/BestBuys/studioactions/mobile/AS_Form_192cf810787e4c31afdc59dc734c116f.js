function AS_Form_192cf810787e4c31afdc59dc734c116f(eventobject) {
    return scrollAnimation.call(this);
}