function AS_FlexContainer_d1340ac56eec410aa1bb812523306eb5(eventobject, x, y) {
    frmProd.flxCon1.zIndex = "1";
    frmProd.flxCon1.setVisibility(false);
    frmProd.tbxSearch.setVisibility(false);
    frmProd.tbxSearch.zIndex = "1";
    frmProd.btnGoSearch.setVisibility(false);
    frmProd.btnGoSearch.zIndex = "1";
    frmProd.flxCon1.lblNoSearch.setVisibility(false);
    frmProd.forceLayout();
}