function AS_Image_e9be2253e34243e396bf5e860105f7e0(eventobject, x, y) {
    return backStack.call(this);
}