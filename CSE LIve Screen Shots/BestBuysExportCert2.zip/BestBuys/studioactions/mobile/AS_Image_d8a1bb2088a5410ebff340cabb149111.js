function AS_Image_d8a1bb2088a5410ebff340cabb149111(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}