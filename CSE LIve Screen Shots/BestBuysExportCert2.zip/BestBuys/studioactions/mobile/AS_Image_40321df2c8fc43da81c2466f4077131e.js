function AS_Image_40321df2c8fc43da81c2466f4077131e(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.btnGoSearch.setVisibility(true);
    frmPdetails.btnGoSearch.zIndex = "5";
    frmPdetails.forceLayout();
}