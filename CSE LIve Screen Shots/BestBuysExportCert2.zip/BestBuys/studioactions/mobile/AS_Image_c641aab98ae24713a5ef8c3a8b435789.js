function AS_Image_c641aab98ae24713a5ef8c3a8b435789(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}