function AS_Image_eef66dc4e5c44ba4aaae797884b84d01(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}