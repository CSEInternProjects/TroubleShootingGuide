function initializetempSeg() {
    flxCat = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "39dp",
        "id": "flxCat",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox01db4d0b4b21649"
    }, {}, {});
    flxCat.setDefaultUnit(kony.flex.DP);
    var lblCat = new kony.ui.Label({
        "id": "lblCat",
        "isVisible": true,
        "left": "3dp",
        "skin": "CopyslLabel0844eacb1e7824f",
        "text": "Label",
        "top": "5dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    flxCat.add(lblCat);
}