function AS_Button_je1d609c4ce5411dba51980d9d598ab9(eventobject) {
    return moveAnimation2.call(this);
}