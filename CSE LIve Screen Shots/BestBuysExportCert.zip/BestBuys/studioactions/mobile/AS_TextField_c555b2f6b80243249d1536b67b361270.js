function AS_TextField_c555b2f6b80243249d1536b67b361270(eventobject, changedtext) {
    searchNow("Cats");
}