function AS_Image_ied5bd47d5a54c75a8da367e402a8683(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}