function AS_Button_2315845681de4b5985c92d30332ed92d(eventobject) {
    frmCat.flxCon1.zIndex = "1";
    frmCat.flxCon1.setVisibility(false);
    frmCat.tbxSearch.setVisibility(false);
    frmCat.tbxSearch.text = "";
    frmCat.tbxSearch.zIndex = "1";
    frmCat.btnGoSearch.setVisibility(false);
    frmCat.btnGoSearch.zIndex = "1";
    frmCat.flxCon1.lblNoSearch.setVisibility(false);
    frmCat.forceLayout();
}