function AS_Image_56ccf0cded664f059c44cb7f237d0322(eventobject, x, y) {
    frmCat.flxCon1.setVisibility(true);
    frmCat.flxCon1.zIndex = "5";
    frmCat.flxCon2.zIndex = "5";
    kony.print("value of flx container" + frmCat.flxCon1.zIndex);
    frmCat.tbxSearch.setVisibility(true);
    frmCat.tbxSearch.zIndex = "5";
    frmCat.tbxSearch.text = "Search";
    frmCat.btnGoSearch.setVisibility(true);
    frmCat.btnGoSearch.zIndex = "5";
    frmCat.segCat.zIndex = "2";
    kony.print("value of segment" + frmCat.segCat.zIndex);
    frmCat.forceLayout();
    moveAnimation();
}