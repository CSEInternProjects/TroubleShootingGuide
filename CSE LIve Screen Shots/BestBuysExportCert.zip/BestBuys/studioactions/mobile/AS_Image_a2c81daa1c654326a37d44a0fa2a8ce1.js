function AS_Image_a2c81daa1c654326a37d44a0fa2a8ce1(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}