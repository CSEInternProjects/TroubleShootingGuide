function addWidgetsfrmPdetails() {
    frmPdetails.setDefaultUnit(kony.flex.DP);
    var tbxSearch = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "tbxSearch",
        "isVisible": false,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "10dp",
        "maxTextLength": null,
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Search",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "57dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var lblRev = new kony.ui.Label({
        "id": "lblRev",
        "isVisible": false,
        "left": 52,
        "skin": "CopyslLabel078f7f1f260ef45",
        "text": "No reviews found",
        "top": 376,
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var segRev = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "50%",
        "data": [{
            "imgRat": "imagedrag.png",
            "revDesc": "Label",
            "revName": "Label",
            "revTit": "Label"
        }, {
            "imgRat": "imagedrag.png",
            "revDesc": "Label",
            "revName": "Label",
            "revTit": "Label"
        }, {
            "imgRat": "imagedrag.png",
            "revDesc": "Label",
            "revName": "Label",
            "revTit": "Label"
        }, {
            "imgRat": "imagedrag.png",
            "revDesc": "Label",
            "revName": "Label",
            "revTit": "Label "
        }],
        "groupCells": true,
        "height": "50%",
        "id": "segRev",
        "isVisible": true,
        "left": "2%",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg023a11ff5b58440",
        "rowTemplate": flxDetails,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": true,
        "showScrollbars": true,
        "top": "50%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxDetails": "flxDetails",
            "imgRat": "imgRat",
            "revDesc": "revDesc",
            "revName": "revName",
            "revTit": "revTit"
        },
        "width": "96%",
        "zIndex": 2
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var segDetails = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "RTxtMore": "more...\n",
            "Rat": "Rating",
            "img2": "imagedrag.png",
            "imgRat2": "imagedrag.png",
            "lblDesc": "Label",
            "lblName": "Label",
            "lblPrice2": "Label"
        }],
        "groupCells": false,
        "height": "34.42%",
        "id": "segDetails",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "Copyseg011a9a2a48e8b48",
        "rowTemplate": flxCat3,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "10%",
        "viewType": constants.SEGUI_VIEW_TYPE_PAGEVIEW,
        "widgetDataMap": {
            "RTxtMore": "RTxtMore",
            "Rat": "Rat",
            "flxCat3": "flxCat3",
            "flxLblVer": "flxLblVer",
            "img2": "img2",
            "imgRat2": "imgRat2",
            "lblDesc": "lblDesc",
            "lblName": "lblName",
            "lblPrice2": "lblPrice2"
        },
        "width": "100%",
        "zIndex": 2
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRevCount = new kony.ui.Label({
        "id": "lblRevCount",
        "isVisible": false,
        "left": "320dp",
        "skin": "CopyslLabel022c3ecfc94834e",
        "text": "0",
        "top": "286dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_BOTTOM_RIGHT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var lblRevCount2 = new kony.ui.Label({
        "height": "5%",
        "id": "lblRevCount2",
        "isVisible": true,
        "left": "3%",
        "skin": "CopyslLabel0a777173c500c43",
        "text": "Number of Reviews:",
        "top": "45%",
        "width": "97%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kmb14652df27d4c4ba1e0ba3c3c2f9d11 = new kony.ui.FlexContainer({
        "clipBounds": true,
        "isMaster": true,
        "height": "10%",
        "id": "flxMaster",
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "top": "0%",
        "width": "100%",
        "zIndex": 2,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "isVisible": true,
        "skin": "CopyslFbox07e41b77d98ba4c"
    }, {}, {});
    kmb14652df27d4c4ba1e0ba3c3c2f9d11.setDefaultUnit(kony.flex.DP);
    var kmc753c2fda144730b98b280111ea7cfe = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "75%",
        "id": "imgBestBuy",
        "src": "bestbuylogo.png",
        "top": "9%",
        "width": "31%",
        "zIndex": 1,
        "isVisible": true,
        "left": "140%",
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var kmaa7bf5144794b058dba27fd0e7a4eee = new kony.ui.Label({
        "centerX": "50.00%",
        "centerY": "96.41%",
        "height": "3%",
        "id": "lblDivider",
        "left": "0dp",
        "text": "Label",
        "textStyle": {},
        "top": "7%",
        "width": "100%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel07ba66cdf3edf46"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var kmbe1bc327ea24474bfb3c25e1ebc12d1 = new kony.ui.Image2({
        "height": "78%",
        "id": "imgBack",
        "left": "1%",
        "onTouchEnd": AS_Image_cb36dc1e31ac4f779f6f7b401b87c482,
        "onTouchStart": AS_Image_a5bc60b239654ca1b7f1551f5f99360c,
        "src": "ic_menu_back.png",
        "top": "4%",
        "width": "18%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var km409f1c00a2e49fe952a5e29d8c0c182 = new kony.ui.Image2({
        "height": "54dp",
        "id": "btnSearch",
        "left": "294dp",
        "onTouchEnd": AS_Image_e58490a5d9f84d3fa2c31e38cae01b64,
        "src": "ic_menu_search.png",
        "top": "9%",
        "width": "80dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage022f63153460143"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmb14652df27d4c4ba1e0ba3c3c2f9d11.add(kmc753c2fda144730b98b280111ea7cfe, kmaa7bf5144794b058dba27fd0e7a4eee, kmbe1bc327ea24474bfb3c25e1ebc12d1, km409f1c00a2e49fe952a5e29d8c0c182);
    frmPdetails.add(tbxSearch, lblRev, segRev, segDetails, lblRevCount, lblRevCount2, kmb14652df27d4c4ba1e0ba3c3c2f9d11);
};

function frmPdetailsGlobals() {
    frmPdetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmPdetails,
        "enabledForIdleTimeout": false,
        "id": "frmPdetails",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0a4570de32a5f4b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
};