//Type your code here
function scaleAnimation() {
    frmProd.forceLayout();
    var transformObj1 = kony.ui.makeAffineTransform();
    var transformObj2 = kony.ui.makeAffineTransform();
    // This will be invoked when you click on translate button
    transformObj1.scale(0, 0);
    transformObj2.scale(1, 1);
    var animationObject = kony.ui.createAnimation({
        "0": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "transform": transformObj1,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        },
        "100": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "transform": transformObj2,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        }
    });
    var animationConfig = {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    var animationCallbacks = {
        "animationEnd": function() {
            kony.print("animation END");
        }
    };
    var animationDefObject = {
        definition: animationObject,
        config: animationConfig,
        callbacks: animationCallbacks
    };
    frmProd.forceLayout();
    frmProd.segCat2.setAnimations({
        visible: animationDefObject
    });
    frmProd.forceLayout();
}

function scrollAnimation() {
    var transformObj1 = kony.ui.makeAffineTransform();
    var transformObj2 = kony.ui.makeAffineTransform();
    // This will be invoked when you click on translate button
    transformObj1.translate(300, 0);
    transformObj2.translate(0, 0);
    var animationObject = kony.ui.createAnimation({
        "0": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "transform": transformObj1,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        },
        "100": {
            "anchorPoint": {
                "x": 0.5,
                "y": 0.5
            },
            "transform": transformObj2,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        }
    });
    var animationConfig = {
        duration: 1,
        fillMode: kony.anim.FILL_MODE_FORWARDS
    };
    var animationCallbacks = {
        "animationEnd": function() {
            kony.print("animation END");
        }
    };
    var animationDefObject = {
        definition: animationObject,
        config: animationConfig,
        callbacks: animationCallbacks
    };
    frmCat.segCat.setAnimations({
        visible: animationDefObject
    });
}

function stepConfig() {
    var tranformObject = kony.ui.makeAffineTransform();
    tranformObject.rotate3D(90, 0, 1, 0);
    tranformObject.setPerspective(1000);
    var animationStepConfig = kony.ui.createAnimation({
        "100": {
            "transform": tranformObject,
            "stepConfig": {
                "timingFunction": kony.anim.LINEAR
            }
        }
    });
    return animationStepConfig;
}

function timingConfig() {
    var animationTimeConfig = {
        "delay": 0,
        "iterationCount": 1,
        "fillMode": kony.anim.FILL_MODE_FORWARDS,
        "duration": 0.5
    };
    return animationTimeConfig;
}

function callbackConfig() {
    var animationCallbackconfig = {
        "animationEnd": function() {
            var transformObject1 = kony.ui.makeAffineTransform();
            transformObject1.rotate3D(90, 0, 1, 0);
            transformObject1.setPerspective(1000);
            var transformObject2 = kony.ui.makeAffineTransform();
            transformObject2.rotate3D(0, 0, 1, 0);
            transformObject2.setPerspective(1000);
            var animconfig = kony.ui.createAnimation({
                "0": {
                    "transform": transformObject1,
                    "stepConfig": {
                        "timingFunction": kony.anim.LINEAR
                    }
                },
                "100": {
                    "transform": transformObject2,
                    "stepConfig": {
                        "timingFunction": kony.anim.LINEAR
                    }
                }
            });
            var timingconfig = {
                "delay": 0,
                "iterationCount": 1,
                "fillMode": kony.anim.FILL_MODE_FORWARDS,
                "duration": 0.5
            };
            if (currentWidgetType == "image") {
                //frmpro.imgCar.setVisibility(false);
                //frmpro.lblCarInfo.setVisibility(true);
                //frmpro.lblCarInfo.animate(animconfig,timingconfig, null); 
                frmProd.lblPage.setVisibility(false);
                frmProd.lblPage2.setVisibility(true);
                frmProd.forceLayout();
                frmProd.lblPage2.animate(animconfig, timingconfig, null);
            } else {
                //frmpro.lblCarInfo.setVisibility(false);
                //frmpro.imgCar.setVisibility(true);
                //frmpro.imgCar.animate(animconfig,timingconfig, null);  
                frmProd.lblPage2.setVisibility(false);
                frmProd.lblPage.setVisibility(true);
                frmProd.forceLayout();
                frmProd.lblPage.animate(animconfig, timingconfig, null);
            }
        }
    };
    return animationCallbackconfig;
}
widgetType = "image";

function animate3D() {
    currentWidgetType = widgetType;
    if (widgetType == "image") {
        //frmpro.lblCarInfo.setVisibility(false);
        frmProd.lblPage2.setVisibility(false);
        frmProd.forceLayout();
        //frmpro.imgCar.animate(stepConfig(), timingConfig(), callbackConfig());
        frmProd.lblPage.animate(stepConfig(), timingConfig(), callbackConfig());
        widgetType = "heyy";
    } else {
        //frmpro.imgCar.setVisibility(false);
        frmProd.lblPage.setVisibility(false);
        frmProd.forceLayout();
        //frmpro.lblCarInfo.animate(stepConfig(), timingConfig(), callbackConfig());
        frmProd.lblPage2.animate(stepConfig(), timingConfig(), callbackConfig());
        widgetType = "image";
    }
}