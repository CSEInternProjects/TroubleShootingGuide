function addWidgetsfrmCat() {
    frmCat.setDefaultUnit(kony.flex.DP);
    var segCat = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblCat": "Label"
        }, {
            "lblCat": "Label"
        }, {
            "lblCat": "Label"
        }],
        "groupCells": false,
        "height": "445dp",
        "id": "segCat",
        "isVisible": true,
        "needPageIndicator": true,
        "onRowClick": AS_Segment_5be3e22ddd164803852c448ae8780305,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxCat,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxCat": "flxCat",
            "lblCat": "lblCat"
        },
        "width": "99.77%",
        "zIndex": 2
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblDisp = new kony.ui.Label({
        "id": "lblDisp",
        "isVisible": true,
        "left": "4dp",
        "skin": "CopyslLabel048e11b46c77d49",
        "text": "Home",
        "top": "65dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var symb = new kony.ui.Image2({
        "centerX": "50%",
        "height": "36dp",
        "id": "symb",
        "isVisible": true,
        "left": "140dp",
        "skin": "slImage",
        "src": "bestbuylogo.png",
        "top": "5dp",
        "width": "65dp",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var back = new kony.ui.Image2({
        "height": "31dp",
        "id": "back",
        "isVisible": true,
        "left": "0dp",
        "onTouchStart": AS_Image_5c6a9e5cf31846538784d1c08d9b0c4c,
        "skin": "slImage",
        "src": "ic_menu_back.png",
        "top": "8dp",
        "width": "45dp",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var search = new kony.ui.Image2({
        "height": "36dp",
        "id": "search",
        "isVisible": true,
        "left": "320dp",
        "onTouchStart": AS_Image_56ccf0cded664f059c44cb7f237d0322,
        "skin": "slImage",
        "src": "ic_menu_search.png",
        "top": "5dp",
        "width": "45dp",
        "zIndex": 2
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var flxCon1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "575dp",
        "id": "flxCon1",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "onTouchStart": AS_FlexContainer_87d9b1529c224ada8a045ac3e7702cf1,
        "skin": "CopyslFbox08333b29d7f324f",
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxCon1.setDefaultUnit(kony.flex.DP);
    var lblNoSearch = new kony.ui.Label({
        "id": "lblNoSearch",
        "isVisible": false,
        "left": "43dp",
        "skin": "CopyslLabel0c4a4a47bf13144",
        "text": "Search not found",
        "top": "343dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    flxCon1.add(lblNoSearch);
    var tbxSearch = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "tbxSearch",
        "isVisible": false,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "4dp",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Search",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "55dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var btnGoSearch = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "40dp",
        "id": "btnGoSearch",
        "isVisible": false,
        "left": "282dp",
        "onClick": AS_Button_2315845681de4b5985c92d30332ed92d,
        "skin": "slButtonGlossBlue",
        "text": "Go!!",
        "top": "55dp",
        "width": "76dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    frmCat.add(segCat, lblDisp, symb, back, search, flxCon1, tbxSearch, btnGoSearch);
};

function frmCatGlobals() {
    frmCat = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCat,
        "enabledForIdleTimeout": false,
        "id": "frmCat",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "postShow": AS_Form_dd38d2a4a5104d608743a4f107c2c0e8,
        "preShow": AS_Form_192cf810787e4c31afdc59dc734c116f,
        "skin": "CopyslForm015cc8557b96745"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmCat.info = {
        "kuid": "6ff7fd6cff4b4f36afa668f91de717b2"
    };
};