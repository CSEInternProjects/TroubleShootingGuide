function initializetempSeg2() {
    flxCat2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "185dp",
        "id": "flxCat2",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "CopyslFbox01db4d0b4b21649"
    }, {}, {});
    flxCat2.setDefaultUnit(kony.flex.DP);
    var lblName = new kony.ui.Label({
        "bottom": 5,
        "id": "lblName",
        "isVisible": true,
        "left": "37.90%",
        "maxHeight": "77%",
        "skin": "CopyslLabel0e681cc9438b849",
        "text": "Label",
        "top": "25dp",
        "width": "62.09%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var imgProd = new kony.ui.Image2({
        "height": "133dp",
        "id": "imgProd",
        "isVisible": true,
        "left": "10dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "25dp",
        "width": "120dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPrice = new kony.ui.Label({
        "bottom": 5,
        "centerX": "60%",
        "centerY": "82%",
        "id": "lblPrice",
        "isVisible": true,
        "skin": "CopyslLabel0e681cc9438b849",
        "text": "Label",
        "width": "40.00%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var imgRating = new kony.ui.Image2({
        "centerX": "76.6%",
        "centerY": "87%",
        "height": "35dp",
        "id": "imgRating",
        "isVisible": true,
        "left": "120dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "140dp",
        "width": "130dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblRat = new kony.ui.Label({
        "id": "lblRat",
        "isVisible": true,
        "left": "159dp",
        "skin": "CopyslLabel01e6f5cb864d64f",
        "text": "Label",
        "top": "150dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblID = new kony.ui.Label({
        "id": "lblID",
        "isVisible": false,
        "left": "215dp",
        "skin": "slLabel",
        "text": "Label",
        "top": "30dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblSaleNote = new kony.ui.Label({
        "id": "lblSaleNote",
        "isVisible": true,
        "left": "109dp",
        "skin": "CopyslLabel08e3524c7e54f4c",
        "text": "Label",
        "top": "5dp",
        "width": "70%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    flxCat2.add(lblName, imgProd, lblPrice, imgRating, lblRat, lblID, lblSaleNote);
}