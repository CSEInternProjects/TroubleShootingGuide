//actions.js file 
function actPreShow(eventobject) {
    return AS_Form_75da9facc5bf40cc83c7d295e19ae683(eventobject);
}

function AS_Form_75da9facc5bf40cc83c7d295e19ae683(eventobject) {}

function actSegRowTouch(eventobject, sectionNumber, rowNumber) {
    return AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber);
}

function AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber) {
    return segRowTouch.call(this);
}

function AS_Button_0d56ca5d9cbe466f9ba8c902149415eb(eventobject) {
    return backPrev.call(this);
}

function AS_Button_2315845681de4b5985c92d30332ed92d(eventobject) {
    searchNow("Cats");
}

function AS_Button_68ad07f5533e4c41b6a6622f7f6eb952(eventobject) {
    backPrev.call(this);
    animate3D.call(this);
}

function AS_Button_f003de79f3d94b3689babfb3b71bca41(eventobject) {
    goNext.call(this);
    animate3D.call(this);
}

function AS_FlexContainer_1faba13b4fe84004b56e896ccd0a1069(eventobject, x, y) {
    frmPdetails.flxCon1.zIndex = "1";
    frmPdetails.flxCon1.setVisibility(false);
    frmPdetails.tbxSearch.setVisibility(false);
    frmPdetails.tbxSearch.zIndex = "1";
    frmPdetails.btnGoSearch.setVisibility(false);
    frmPdetails.btnGoSearch.zIndex = "1";
    frmPdetails.flxCon1.lblNoSearch.setVisibility(false);
    frmPdetails.forceLayout();
}

function AS_FlexContainer_87d9b1529c224ada8a045ac3e7702cf1(eventobject, x, y) {
    frmCat.flxCon1.zIndex = "1";
    frmCat.flxCon1.setVisibility(false);
    frmCat.tbxSearch.setVisibility(false);
    frmCat.tbxSearch.zIndex = "1";
    frmCat.btnGoSearch.setVisibility(false);
    frmCat.btnGoSearch.zIndex = "1";
    frmCat.flxCon1.lblNoSearch.setVisibility(false);
    frmCat.forceLayout();
}

function AS_FlexContainer_d1340ac56eec410aa1bb812523306eb5(eventobject, x, y) {
    frmProd.flxCon1.zIndex = "1";
    frmProd.flxCon1.setVisibility(false);
    frmProd.tbxSearch.setVisibility(false);
    frmProd.tbxSearch.zIndex = "1";
    frmProd.btnGoSearch.setVisibility(false);
    frmProd.btnGoSearch.zIndex = "1";
    frmProd.flxCon1.lblNoSearch.setVisibility(false);
    frmProd.forceLayout();
}

function AS_Form_140805a6f7df4893a512850995aed906(eventobject) {}

function AS_Form_192cf810787e4c31afdc59dc734c116f(eventobject) {
    return scrollAnimation.call(this);
}

function AS_Form_4b0946f668cc47b0a10ee5e29468850b(eventobject) {}

function AS_Form_99cbc2b9675e4176ab41cf2ac1ad06c3(eventobject) {
    return scaleAnimation.call(this);
}

function AS_Form_a6ec2d230cb24661814244ec825443b4(eventobject) {}

function AS_Form_af96431d47e84edf87bcd83b46c13f10(eventobject) {
    return retrieveCat.call(this);
}

function AS_Form_dd38d2a4a5104d608743a4f107c2c0e8(eventobject) {
    return retrieveCat.call(this);
}

function AS_Image_0ef8f5209c174765a6cac3742e8564bc(eventobject, x, y) {
    return frmBack22.call(this);
}

function AS_Image_3ff8269b7729481dab6188df7b97312c(eventobject, x, y) {}

function AS_Image_40321df2c8fc43da81c2466f4077131e(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.btnGoSearch.setVisibility(true);
    frmPdetails.btnGoSearch.zIndex = "5";
    frmPdetails.forceLayout();
}

function AS_Image_56ccf0cded664f059c44cb7f237d0322(eventobject, x, y) {
    frmCat.flxCon1.setVisibility(true);
    frmCat.flxCon1.zIndex = "4";
    frmCat.tbxSearch.setVisibility(true);
    frmCat.tbxSearch.zIndex = "5";
    frmCat.btnGoSearch.setVisibility(true);
    frmCat.btnGoSearch.zIndex = "5";
    frmCat.forceLayout();
}

function AS_Image_5c6a9e5cf31846538784d1c08d9b0c4c(eventobject, x, y) {
    return backStack.call(this);
}

function AS_Image_bc27df41ab2943d8993c83b56c27705c(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.forceLayout();
}

function AS_Image_d316523a83f24849b9e74b2b80409efe(eventobject, x, y) {
    frmProd.flxCon1.setVisibility(true);
    frmProd.flxCon1.zIndex = "4";
    frmProd.tbxSearch.setVisibility(true);
    frmProd.tbxSearch.zIndex = "5";
    frmProd.btnGoSearch.setVisibility(true);
    frmProd.btnGoSearch.zIndex = "5";
    frmProd.forceLayout();
}

function AS_Image_db0f5fefa5b4402b9c2a498f56a562a6(eventobject, x, y) {
    return onClickBack3.call(this);
}

function AS_Image_db6f8f4f031e40a883b87b867955a6d4(eventobject, x, y) {}

function AS_Label_a11d78ad137c4415a5f6861face98c33(eventobject, x, y) {}

function AS_Segment_02f51a4df32c4626b0482e7125537032(eventobject, sectionNumber, rowNumber) {
    return segRowTouchTwo.call(this);
}

function AS_Segment_91891c4b83984df9ba322e5ecd11a435(eventobject, sectionNumber, rowNumber) {}