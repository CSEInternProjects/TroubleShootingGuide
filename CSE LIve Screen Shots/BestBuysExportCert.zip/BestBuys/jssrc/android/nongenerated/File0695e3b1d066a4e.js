//Type your code here
//Type your code here
mobileFabricConfiguration = {
    appKey: "1f3f9f1ede2449bcafc9955b79cd0fe",
    appSecret: "e4a075880210f40a12d1251b5ad1d77c",
    serviceURL: "https://productsupport.konylabs.net/authService/100000002/appconfig",
    //appKey:"5fd11c44af43e233f2a9bb09e0100f47", 
    //appSecret:"c600a59925b36419de1546056cd21557", 
    //serviceURL:"https://100000507.auth.konycloud.com/appconfig",
    integrationServices: [{
        service: "categories",
        operations: ["getCategories"]
    }],
    identityServices: [{
        service: "userstore",
        username: "bharadwaj.pardhasaradhi@kony.com",
        password: "Kony@123"
    }],
    konysdkObject: null,
    authClient: null,
    integrationObj: null,
    isKonySDKObjectInitialized: false,
    isMFAuthenticated: false
};
initialCheck = 0;
unique = 0;
p = 0;
k = 0;
temp2 = 0;
hm = ["Home"];
hm2 = ["Home"];
frm = 0;
countH = 0;
track = "";
mySearch = "";
searchActive = 0;
searchAgain = 0;
sPageNo = 1;
searchBack = 0;
temp = 0;
stack2 = {
    arr2: []
};
stack3 = {
    arr3: []
};
stackTop3 = 0;
// Function to invoke getFoxNews Service call
function retrieveCat() {
    if (initialCheck === 0) {
        // frmCat.segCat.centerX="49%";
        //frmCat.segCat.centerY="350dp";
        //frmCat.forceLayout();
        initialCheck = 1;
        var selectedKey = "nothing";
        // Let's get the news type the user selected
        //	var selectedKey = frmFoxNews.lstNewsType.selectedKey;
        kony.print("########## Selected Key:" + selectedKey);
        // Let's first check that the user picked a valid value
        //if (!kony.string.equalsIgnoreCase(selectedKey, "none"))
        // Populating the input params for the service call and invoking the service
        // We're passing in the selected key for the user's selection in the combobox
        // var inputParams = {serviceID:"getFoxNews",newsType:selectedKey};
        // Now we make the call to the service using our input parameters and specifying
        // the function processServiceResults as our callback when the service returns results
        // appmiddlewareinvokerasync(inputParams, processServiceResults);
        if (!mobileFabricConfiguration.isKonySDKObjectInitialized) {
            initializeMobileFabric();
        } else if (mobileFabricConfiguration.isKonySDKObjectInitialized) {
            getCat();
        }
        //}
        else {
            // The user didn't pick a value so we'll show the alert
            kony.ui.Alert({
                message: "Please select a validations",
                alertType: constants.ALERT_TYPE_INFO,
                alertTitle: "Fox News",
                yesLabel: "OK"
            }, {});
        }
    }
}
stackTop = 0;
stackTop2 = 0;

function initializeMobileFabric() {
    kony.print(" ********** Entering into initializeMobileFabric ********** ");
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        kony.application.showLoadingScreen("loadskin", "Initializing the app !!!", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {
            enableMenuKey: true,
            enableBackKey: true,
            progressIndicatorColor: "ffffff77"
        });
        mobileFabricConfiguration.konysdkObject = new kony.sdk();
        mobileFabricConfiguration.konysdkObject.init(mobileFabricConfiguration.appKey, mobileFabricConfiguration.appSecret, mobileFabricConfiguration.serviceURL, initializeMobileFabricSuccess, initializeMobileFabricFailure);
    } else alert("Network unavailable. Please check your network settings. ");
    kony.print(" ********** Exiting out of initializeMobileFabric ********** ");
}

function initializeMobileFabricSuccess(response) {
    kony.print(" ********** Entering into initializeMobileFabricSuccess ********** ");
    kony.print(" ********** Success initializeMobileFabricSuccess response : " + JSON.stringify(response) + " ********** ");
    mobileFabricConfiguration.isKonySDKObjectInitialized = true;
    kony.application.dismissLoadingScreen();
    authenticateMFUsingUserStore();
    kony.print(" ********** Exiting out of initializeMobileFabricSuccess ********** ");
}

function initializeMobileFabricFailure(error) {
    kony.print(" ********** Entering into initializeMobileFabricFailure ********** ");
    kony.print(" ********** Failure in initializeMobileFabric: " + JSON.stringify(error) + " ********** ");
    kony.application.dismissLoadingScreen();
    alert(" Unable to initialize the application. Please try again. ");
    kony.print(" ********** Exiting out of initializeMobileFabricFailure ********** ");
}

function authenticateMFUsingUserStore() {
    kony.print(" ********** Entering into authenticateMFUsingUserStore ********** ");
    kony.application.showLoadingScreen("loadskin", "Loading !!!", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, false, true, {
        enableMenuKey: true,
        enableBackKey: true,
        progressIndicatorColor: "ffffff77"
    });
    mobileFabricConfiguration.authClient = mobileFabricConfiguration.konysdkObject.getIdentityService(mobileFabricConfiguration.identityServices[0].service);
    var authParams = {
        "userid": mobileFabricConfiguration.identityServices[0].username,
        "password": mobileFabricConfiguration.identityServices[0].password
    };
    mobileFabricConfiguration.authClient.login(authParams, loginMFSuccess, loginMFFailure);
    kony.print(" ********** Exiting out of authenticateMFUsingUserStore ********** ");
}

function loginMFSuccess(response) {
    kony.print(" ********** Entering into loginMFSuccess ********** ");
    kony.print(" ********** Success loginMFSuccess response : " + JSON.stringify(response) + " ********** ");
    mobileFabricConfiguration.isMFAuthenticated = true;
    kony.application.dismissLoadingScreen();
    getCat();
    kony.print(" ********** Exiting out of loginMFSuccess ********** ");
}

function loginMFFailure(error) {
    kony.print(" ********** Entering into loginMFFailure ********** ");
    kony.print(" ********** Failure in loginMFFailure: " + JSON.stringify(error) + " ********** ");
    kony.application.dismissLoadingScreen();
    alert(" Unable to authenticate to Server, Login failed. Please try again. ");
    kony.print(" ********** Exiting out of loginMFFailure ********** ");
}

function getCat() {
    //var selectedKey = frmFoxNews.lstNewsType.selectedKey;
    Cat = "cat00000";
    frmProd.flxMaster.btnSearch.setVisibility(false);
    frmPdetails.flxMaster.btnSearch.setVisibility(false);
    frmPdetails.flxMaster.imgBestBuy.setVisibility(true);
    if (kony.net.isNetworkAvailable(constants.NETWORK_TYPE_ANY)) {
        kony.application.showLoadingScreen("loadskin", "Loading !!!", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, false, true, {
            enableMenuKey: true,
            enableBackKey: true,
            progressIndicatorColor: "ffffff77"
        });
        kony.print("1");
        mobileFabricConfiguration.integrationObj = mobileFabricConfiguration.konysdkObject.getIntegrationService(mobileFabricConfiguration.integrationServices[0].service);
        //	var operationName = mobileFabricConfiguration.integrationServices[0].operations[0];
        var headers = {};
        var data = {
            "catId": Cat
        };
        var get = "getCategories";
        // The user didn't pick a value so we'll show the alert
        //    kony.ui.Alert({ message: "Please select a valid news type",alertType:constants. ALERT_TYPE_INFO, alertTitle:"BusyBuy",yesLabel:"OK"}, {});
        kony.print("2");
        mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallback, getNewsErrorCallback);
    } else alert("Network unavailable. Please check your network settings. ");
}

function getNewsSuccessCallback(BestBuyResponse) {
    if (stackTop === 0) {
        frmCat.flxMaster.imgBack.setVisibility(false);
    }
    kony.print("3");
    // Check the opstatus for 0 meaning it worked
    if (BestBuyResponse !== null && BestBuyResponse.opstatus === 0) {
        // Checking to make sure we DO have results
        if (BestBuyResponse.categories !== null) {
            // Making sure we have at least 1 article returned
            if (BestBuyResponse.categories.length > 0) {
                kony.print("4");
                // Now we know we have results so we'll print them out to check
                //kony.print ("########## Response received from service call: "+JSON.stringify(BesyBuyResponse));
                //Setting the segment widgetdataMap 
                // c=  BestBuyResponse.categories[0].CatNames;
                //frmCat.lblDisp.text=c;
                //frmCat.lblDisp.setVisibility(true);
                frmCat.segCat.widgetDataMap = {
                    lblCat: "CatNames"
                };
                // Setting the data to the segment
                //frmFoxNews.segNewsTitle.setVisibility(true);
                frmCat.segCat.setData(BestBuyResponse.categories);
                // frmCat.segCat.centerX="49%";
                // frmCat.segCat.centerY="350dp";
                // frmCat.forceLayout();
                Best = BestBuyResponse;
                stack = {
                    arr: [Best]
                };
                frmCat.lblDisp.text = stack.arr[0].categories[0].catIds;
                frmCat.lblDisp.text = "Home";
                frmCat.lblDisp.setVisibility(true);
                //frmCat.segCat.centerX="50%";
                // frmCat.segCat.centerY="50%";
                //frmCat.forceLayout();
                frmCat.show();
                kony.application.dismissLoadingScreen();
            }
        }
    } else {
        kony.application.dismissLoadingScreen();
        // The call failed because opstatus was not 0 so we'll alert the user and show that opststus
        kony.ui.Alert({
            message: "Service call failed with opstatus " + BestBuyResponse.opstatus,
            alertType: constants.ALERT_TYPE_ERROR,
            alertTitle: "Best Buy",
            yesLabel: "OK"
        }, {});
    }
}

function getNewsErrorCallback(error) {
    kony.print(" ********** Entering into getNewsErrorCallback ********** ");
    kony.print(" ********** Failure in getNewsErrorCallback: " + JSON.stringify(error) + " ********** ");
    kony.application.dismissLoadingScreen();
    alert(" Failed to fetch the news. Please try again. ");
    kony.print(" ********** Exiting out of getNewsErrorCallback ********** ");
}
// This function navigates to frmNewsDetails and displays the selected segment Record information
function segRowTouch() {
    frmCat.flxMaster.imgBack.setVisibility(true);
    //frmCat.segCat.centerX="49%";
    //frmCat.segCat.centerY="350dp";
    //frmCat.forceLayout();
    kony.print("in 1");
    //kony.application.showLoadingScreen("loadskin","Fetching news !!!",constants.LOADING_SCREEN_POSITION_FULL_SCREEN , false,true,{enableMenuKey:true,enableBackKey:true, progressIndicatorColor : "ffffff77"});	
    var selectedRowData = frmCat.segCat.selectedItems[0]["CatNames"];
    // if(hm[(hm.length-1)]===selectedRowData)
    var q = "";
    hm.push(":");
    hm.push(selectedRowData);
    if (unique === 0) {
        kony.print("inside one");
        hm2.push(selectedRowData);
        unique++;
        countH++;
        kony.print(hm2[countH]);
        frmCat.lblDisp.text = hm2[countH];
        frmCat.lblDisp.setVisibility(true);
    } else {
        kony.print("inside two");
        hm2.push(selectedRowData);
        countH++;
        kony.print(hm2[countH]);
    }
    var i;
    // var x;
    //var i=0;
    /*for(i=0;i<hm.length;i++)
     {
       x=hm[i];
       q=q.concat(x);
       kony.print(""+hm[i]+"***"+q);
     }*/
    q = q.concat(hm2[0]);
    for (i = 1; i < (hm2.length); i++) {
        // x=hm[i];
        q = q.concat("->");
        q = q.concat(hm2[i]);
        kony.print("" + hm2[i] + "***" + q);
    }
    frmCat.lblDisp.text = q;
    // frmCat.lblDisp.text=selectedRowData;   
    frmCat.lblDisp.setVisibility(true);
    setForm(selectedRowData);
}
//	setForm(selectedRowData);	
//}
function setForm(selectedRowData) {
    var f = 0,
        j, i;
    //temp;
    kony.application.showLoadingScreen("loadskin", "loading!", constants.LOADING_SCREEN_POSITION_FULL_SCREEN, true, true, {
        enableMenuKey: true,
        enableBackKey: true,
        progressIndicatorColor: "ffffff77"
    });
    kony.print(stack.arr[stackTop].categories[0].CatNames);
    //for(i=0;i<=stackTop;i++)
    //{
    kony.print(stack.arr[stackTop].categories.length);
    for (j = 0; j < stack.arr[stackTop].categories.length; j++) {
        kony.print(selectedRowData + "=" + stack.arr[stackTop].categories[j].CatNames + "**");
        if (selectedRowData === (stack.arr[stackTop].categories[j].CatNames)) {
            f++;
            kony.print("*******" + stack.arr[stackTop].categories[j].CatNames);
            temp = stack.arr[stackTop].categories[j].catIds;
            kony.print(temp);
            kony.print(stackTop + " *" + j);
            break;
        }
    }
    //if(f>=0)
    //    break;
    // }
    // kony.print(i);
    var headers = {};
    data = {
        "catId": temp
    };
    var get = "getCategories";
    mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallback2, getNewsErrorCallback);
}

function getNewsSuccessCallback2(BestBuyResp) {
    // Check the opstatus for 0 meaning it worked
    if (BestBuyResp !== null && BestBuyResp.opstatus === 0) {
        // Checking to make sure we DO have results
        if (BestBuyResp.categories) {
            // Making sure we have at least 1 article returned
            if (BestBuyResp.categories.length > 0) {
                frmCat.segCat.widgetDataMap = {
                    lblCat: "CatNames"
                };
                // Setting the data to the segment
                //frmFoxNews.segNewsTitle.setVisibility(true);
                frmCat.segCat.setData(BestBuyResp.categories);
                BestTemp = BestBuyResp;
                stack.arr.push(BestTemp);
                stackTop++;
                kony.print("11");
                kony.print(stack.arr[stackTop].categories[0].CatNames);
                kony.application.dismissLoadingScreen();
                // frmCat.lblDisp.text=stack.arr[0].categories[0].catIds;
                //frmCat.lblDisp.setVisibility(true);
                //kony.application.dismissLoadingScreen();
            } else {
                kony.print("44");
                getProducts(temp);
            }
        } else {
            kony.print("44");
            getProducts(temp);
        }
    } else {
        kony.application.dismissLoadingScreen();
        // The call failed because opstatus was not 0 so we'll alert the user and show that opststus
        kony.ui.Alert({
            message: "Service call failed with opstatus " + BestBuyResponse.opstatus,
            alertType: constants.ALERT_TYPE_ERROR,
            alertTitle: "Best Buy",
            yesLabel: "OK"
        }, {});
    }
}

function backStack() {
    if (stackTop === 1) {
        frmCat.flxMaster.imgBack.setVisibility(false);
    }
    if (stackTop === 0) {
        frmCat.flxMaster.imgBack.setVisibility(false);
        while (countH > 0) {
            if (hm2[countH] !== "Home") {
                hm2.pop();
                countH--;
            }
        }
    }
    if (stackTop === 0) {
        frmCat.lblDisp.text = "Home";
        // frmCat.lblDisp.text=selectedRowData;   
        frmCat.lblDisp.setVisibility(true);
    }
    if (stackTop > 0) {
        p = 0;
        stack.arr.pop();
        stackTop--;
        frmCat.segCat.widgetDataMap = {
            lblCat: "CatNames"
        };
        // Setting the data to the segment
        //frmFoxNews.segNewsTitle.setVisibility(true);
        frmCat.segCat.setData(stack.arr[stackTop].categories);
        var i;
        for (i = 0; hm.length < 0; i++) kony.print(hm[i]);
        hm.pop();
        hm.pop();
        if (hm2.length > 1) {
            hm2.pop();
            countH--;
        }
        var q = "";
        var x;
        //if(stack.arr[0].categories[0].CatNames===frmCat.segCat[0][0]);  
        //{
        //  for(i=1;i<hm.length;i--)
        //  {
        //    hm.pop();
        //  }
        //	frmCat.lblDisp.text=hm[0];
        //	frmCat.lblDisp.setVisibility(true);
        //}
        q = q.concat(hm2[0]);
        for (i = 1; i < hm2.length; i++) {
            q = q.concat("->");
            q = q.concat(hm2[i]);
            kony.print("" + hm2[countH] + "***" + q);
        }
        kony.print("***" + q);
        for (i = 0; i < hm2.length; i++) {
            kony.print("*&&*" + hm2[i]);
        }
        /*if(stack.arr[stackTop].categories[0].CatNames==="TV & Home Theater")
       {
          
         hm2.pop();
         countH--;
            
       }
   
    */
        frmCat.lblDisp.text = q;
        // frmCat.lblDisp.text=selectedRowData;   
        frmCat.lblDisp.setVisibility(true);
    }
}