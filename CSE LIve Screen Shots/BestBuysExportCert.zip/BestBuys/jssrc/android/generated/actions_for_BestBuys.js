//actions.js file 
function AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y) {}

function AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y) {}

function actPreShow(eventobject) {
    return AS_Form_75da9facc5bf40cc83c7d295e19ae683(eventobject);
}

function AS_Form_75da9facc5bf40cc83c7d295e19ae683(eventobject) {}

function actSegRowTouch(eventobject, sectionNumber, rowNumber) {
    return AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber);
}

function AS_Segment_5be3e22ddd164803852c448ae8780305(eventobject, sectionNumber, rowNumber) {
    return segRowTouch.call(this);
}

function AS_Button_0d56ca5d9cbe466f9ba8c902149415eb(eventobject) {
    return backPrev.call(this);
}

function AS_Button_2315845681de4b5985c92d30332ed92d(eventobject) {
    frmCat.flxCon1.zIndex = "1";
    frmCat.flxCon1.setVisibility(false);
    frmCat.tbxSearch.setVisibility(false);
    frmCat.tbxSearch.text = "";
    frmCat.tbxSearch.zIndex = "1";
    frmCat.btnGoSearch.setVisibility(false);
    frmCat.btnGoSearch.zIndex = "1";
    frmCat.flxCon1.lblNoSearch.setVisibility(false);
    frmCat.forceLayout();
}

function AS_Button_68ad07f5533e4c41b6a6622f7f6eb952(eventobject) {
    return backPrev.call(this);
}

function AS_Button_87e568fd39a4468fa7db6c595a4a71d1(eventobject) {
    frmCat.flxCon1.zIndex = "1";
    frmCat.flxCon2.zIndex = "1";
    frmCat.flxCon1.setVisibility(false);
    frmCat.tbxSearch.setVisibility(false);
    frmCat.tbxSearch.text = "";
    frmCat.tbxSearch.zIndex = "1";
    frmCat.btnGoSearch.setVisibility(false);
    frmCat.btnGoSearch.zIndex = "1";
    frmCat.flxCon1.lblNoSearch.setVisibility(false);
    frmCat.forceLayout();
}

function AS_Button_cadf140863664b38a769505b35ab9f4d(eventobject) {
    return goNext.call(this);
}

function AS_Button_f003de79f3d94b3689babfb3b71bca41(eventobject) {
    return goNext.call(this);
}

function AS_Button_f33b750f1f684715a6f0d2e5a23e0230(eventobject) {
    return backPrev.call(this);
}

function AS_Button_j85f8d200cbf4ad3a3e3fe4fe314ff3c(eventobject) {
    return backPrev.call(this);
}

function AS_Button_je1d609c4ce5411dba51980d9d598ab9(eventobject) {
    return moveAnimation2.call(this);
}

function AS_FlexContainer_1faba13b4fe84004b56e896ccd0a1069(eventobject, x, y) {
    frmPdetails.flxCon1.zIndex = "1";
    frmPdetails.flxCon1.setVisibility(false);
    frmPdetails.tbxSearch.setVisibility(false);
    frmPdetails.tbxSearch.zIndex = "1";
    frmPdetails.btnGoSearch.setVisibility(false);
    frmPdetails.btnGoSearch.zIndex = "1";
    frmPdetails.flxCon1.lblNoSearch.setVisibility(false);
    frmPdetails.forceLayout();
}

function AS_FlexContainer_87d9b1529c224ada8a045ac3e7702cf1(eventobject, x, y) {}

function AS_FlexContainer_d1340ac56eec410aa1bb812523306eb5(eventobject, x, y) {
    frmProd.flxCon1.zIndex = "1";
    frmProd.flxCon1.setVisibility(false);
    frmProd.tbxSearch.setVisibility(false);
    frmProd.tbxSearch.zIndex = "1";
    frmProd.btnGoSearch.setVisibility(false);
    frmProd.btnGoSearch.zIndex = "1";
    frmProd.flxCon1.lblNoSearch.setVisibility(false);
    frmProd.forceLayout();
}

function AS_Form_140805a6f7df4893a512850995aed906(eventobject) {}

function AS_Form_192cf810787e4c31afdc59dc734c116f(eventobject) {
    return scrollAnimation.call(this);
}

function AS_Form_4b0946f668cc47b0a10ee5e29468850b(eventobject) {}

function AS_Form_99cbc2b9675e4176ab41cf2ac1ad06c3(eventobject) {
    scaleAnimation.call(this);
    frmProd.lblPage.centerX = "50%";
    frmProd.lblPage2.centerX = "50%";
    frmProd.lblPage.centerY = "50%";
    frmProd.lblPage2.centerY = "50%";
    frmProd.forceLayout();
}

function AS_Form_a6ec2d230cb24661814244ec825443b4(eventobject) {}

function AS_Form_af96431d47e84edf87bcd83b46c13f10(eventobject) {
    return retrieveCat.call(this);
}

function AS_Form_dd38d2a4a5104d608743a4f107c2c0e8(eventobject) {
    return retrieveCat.call(this);
}

function AS_Image_0ef8f5209c174765a6cac3742e8564bc(eventobject, x, y) {
    return frmBack22.call(this);
}

function AS_Image_3ff8269b7729481dab6188df7b97312c(eventobject, x, y) {}

function AS_Image_40321df2c8fc43da81c2466f4077131e(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.btnGoSearch.setVisibility(true);
    frmPdetails.btnGoSearch.zIndex = "5";
    frmPdetails.forceLayout();
}

function AS_Image_56ccf0cded664f059c44cb7f237d0322(eventobject, x, y) {
    frmCat.flxCon1.setVisibility(true);
    frmCat.flxCon1.zIndex = "5";
    frmCat.flxCon2.zIndex = "5";
    kony.print("value of flx container" + frmCat.flxCon1.zIndex);
    frmCat.tbxSearch.setVisibility(true);
    frmCat.tbxSearch.zIndex = "5";
    frmCat.tbxSearch.text = "Search";
    frmCat.btnGoSearch.setVisibility(true);
    frmCat.btnGoSearch.zIndex = "5";
    frmCat.segCat.zIndex = "2";
    kony.print("value of segment" + frmCat.segCat.zIndex);
    frmCat.forceLayout();
    moveAnimation();
}

function AS_Image_5c6a9e5cf31846538784d1c08d9b0c4c(eventobject, x, y) {
    return backStack.call(this);
}

function AS_Image_a2c81daa1c654326a37d44a0fa2a8ce1(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Image_a5bc60b239654ca1b7f1551f5f99360c(eventobject, x, y) {
    return onClickBack3.call(this);
}

function AS_Image_b39ed763ff614c47be7faf5940242368(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_bc27df41ab2943d8993c83b56c27705c(eventobject, x, y) {
    frmPdetails.flxCon1.setVisibility(true);
    frmPdetails.flxCon1.zIndex = "4";
    frmPdetails.tbxSearch.setVisibility(true);
    frmPdetails.tbxSearch.zIndex = "5";
    frmPdetails.forceLayout();
}

function AS_Image_c0ed2d16bb154b1ab22816fea193fa55(eventobject, x, y) {
    return frmBack22.call(this);
}

function AS_Image_c396a07a1da8497dadedfdffc0062677(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_c641aab98ae24713a5ef8c3a8b435789(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_cb36dc1e31ac4f779f6f7b401b87c482(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_d316523a83f24849b9e74b2b80409efe(eventobject, x, y) {
    frmProd.flxCon1.setVisibility(true);
    frmProd.flxCon1.zIndex = "4";
    frmProd.tbxSearch.setVisibility(true);
    frmProd.tbxSearch.zIndex = "5";
    frmProd.btnGoSearch.setVisibility(true);
    frmProd.btnGoSearch.zIndex = "5";
    frmProd.forceLayout();
}

function AS_Image_d8a1bb2088a5410ebff340cabb149111(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Image_db0f5fefa5b4402b9c2a498f56a562a6(eventobject, x, y) {
    return onClickBack3.call(this);
}

function AS_Image_db6f8f4f031e40a883b87b867955a6d4(eventobject, x, y) {}

function AS_Image_dd3f780cf96349638385a7b3d3f95a54(eventobject, x, y) {
    return onClickBack3.call(this);
}

function AS_Image_dd43e2d5ffbd4c4cb4cb6d5a4e8ff523(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_e58490a5d9f84d3fa2c31e38cae01b64(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Image_e9be2253e34243e396bf5e860105f7e0(eventobject, x, y) {
    return backStack.call(this);
}

function AS_Image_ebb6265b138e460295b03d250b213d3c(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}

function AS_Image_ebe293706fe340769acd9cd7e8512954(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Image_eef66dc4e5c44ba4aaae797884b84d01(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Image_f74dbe513d044dc38869896412275df7(eventobject, x, y) {
    frmCat.flxMaster.imgBack.setVisibility(false);
    frmCat.flxCon1.setVisibility(true);
    frmCat.flxCon2.setVisibility(true);
    kony.print("value of flx container" + frmCat.flxCon1.zIndex);
    //frmCat.tbxSearch.setVisibility(true);
    //frmCat.tbxSearch.zIndex="5";
    //frmCat.tbxSearch.text="Search";
    //frmCat.btnGoSearch.setVisibility(true);
    //frmCat.btnGoSearch.zIndex="5";
    //frmCat.segCat.zIndex="2";
    kony.print("value of segment" + frmCat.segCat.zIndex);
    //frmCat.forceLayout();
    moveAnimation();
}

function AS_Image_ff6cffdac9794006b1ad80ef6efeb250(eventobject, x, y) {}

function AS_Image_ied5bd47d5a54c75a8da367e402a8683(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}

function AS_Label_a11d78ad137c4415a5f6861face98c33(eventobject, x, y) {}

function AS_Label_ea15045aa9574a48b5d3807b3b601941(eventobject, x, y) {
    return moveAnimation2.call(this);
}

function AS_Segment_02f51a4df32c4626b0482e7125537032(eventobject, sectionNumber, rowNumber) {
    return segRowTouchTwo.call(this);
}

function AS_Segment_91891c4b83984df9ba322e5ecd11a435(eventobject, sectionNumber, rowNumber) {}

function AS_Segment_c6ab25160fdf4c9ea36806df8252f353(eventobject, sectionNumber, rowNumber) {
    return segRowTouch.call(this);
}

function AS_TextField_301a8942011a409cbefaa053b82f823e(eventobject, changedtext) {
    searchNow("Cats");
}

function AS_TextField_c555b2f6b80243249d1536b67b361270(eventobject, changedtext) {
    searchNow("Cats");
}

function AS_TextField_d7c4c83bd73b44f582bf3d5f0c346b4a(eventobject, x, y) {}

function AS_TextField_f41aabdff7404e958275b9882b76e03a(eventobject, changedtext) {
    searchNow("Cats");
}