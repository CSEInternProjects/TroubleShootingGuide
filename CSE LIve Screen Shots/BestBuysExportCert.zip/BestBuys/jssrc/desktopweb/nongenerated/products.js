//Type your code here
function getProducts(temp) {
    kony.print(temp);
    var headers = {};
    pNo = 1;
    temp2 = temp;
    data = {
        "catId": temp,
        "pageNo": pNo
    };
    var get = "getProducts";
    kony.print(11);
    mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallback3, getNewsErrorCallback);
}

function getNewsSuccessCallback3(BestBuyResp) {
    // frmProd.segCat2.top=100;
    //frmProd.forceLayout();
    var i;
    kony.print("I am Here");
    var dollerSign = "price: $";
    kony.print(stack.arr[stackTop].categories[0].CatNames);
    // Check the opstatus for 0 meaning it worked
    if (BestBuyResp !== null && BestBuyResp.opstatus === 0) {
        // Checking to make sure we DO have results
        if (BestBuyResp.productList !== null) {
            // Making sure we have at least 1 article returned
            if (BestBuyResp.productList.length > 0) {
                kony.print(BestBuyResp.productList[0].pAvgReview);
                frm = 1;
                stack2 = {
                    arr2: [BestBuyResp]
                };
                for (i = 0; i < stack2.arr2[0].productList.length; i++) {
                    if (stack2.arr2[0].productList[i].saleNote == "On sale!!") {
                        kony.print(i);
                    } else {}
                    stack2.arr2[0].productList[i].pSalePrice = dollerSign.concat(stack2.arr2[0].productList[i].pSalePrice);
                    kony.print(i);
                    stack2.arr2[0].productList[i].Tex = "Rating";
                    if ((stack2.arr2[0].productList[i].pAvgReview >= 0) && (stack2.arr2[0].productList[i].pAvgReview < 1)) {
                        stack2.arr2[0].productList[i].img = "ratings_star_1.png";
                    } else if ((stack2.arr2[0].productList[i].pAvgReview >= 1) && (stack2.arr2[0].productList[i].pAvgReview < 2)) {
                        stack2.arr2[0].productList[i].img = "ratings_star_2.png";
                    } else if ((stack2.arr2[0].productList[i].pAvgReview >= 2) && (stack2.arr2[0].productList[i].pAvgReview < 3)) {
                        stack2.arr2[0].productList[i].img = "ratings_star_3.png";
                    } else if ((stack2.arr2[0].productList[i].pAvgReview >= 3) && (stack2.arr2[0].productList[i].pAvgReview < 4)) {
                        stack2.arr2[0].productList[i].img = "ratings_star_4.png";
                    } else if ((stack2.arr2[0].productList[i].pAvgReview >= 4) && (stack2.arr2[0].productList[i].pAvgReview <= 5)) {
                        stack2.arr2[0].productList[i].img = "ratings_star_5.png";
                    }
                    if (stack2.arr2[0].productList[i].saleNote === "                                   On sale!!") {
                        stack2.arr2[0].productList[i].pSalePrice2 = stack2.arr2[0].productList[i].pSalePrice;
                        stack2.arr2[0].productList[i].pSalePrice1 = "";
                    } else {
                        stack2.arr2[0].productList[i].pSalePrice1 = stack2.arr2[0].productList[i].pSalePrice;
                        stack2.arr2[0].productList[i].pSalePrice2 = "";
                    }
                }
                frmProd.segCat2.widgetDataMap = {
                    lblSaleNote: "saleNote",
                    lblID: "pId",
                    lblRat: "Tex",
                    imgProd: "pImage",
                    imgRating: "img",
                    lblName: "pName",
                    lblPrice: "pSalePrice1",
                    lblPriceRed: "pSalePrice2"
                };
                frmProd.segCat2.setData(stack2.arr2[0].productList);
                var w = "page";
                w = w.concat(stack2.arr2[0].currentPage);
                w = w.concat("of");
                w = w.concat(stack2.arr2[0].totalPages);
                frmProd.lblPage.text = w;
                frmProd.lblPage2.text = w;
                // frmProd.lblPage.centerX="50%";
                // frmProd.lblPage.centeY="93.5%";
                //   frmProd.forceLayout(); 
                //var  ImgData=[]
                if (frm === 1) {
                    var q = "";
                    q = q.concat("catogories:");
                    q = q.concat(hm2[countH]);
                    frmProd.lblDisp2.text = q;
                }
                k = stack2.arr2[0].currentPage;
                if (k === stack2.arr2[0].totalPages) {
                    frmProd.btnNext.setVisibility(false);
                    //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
                } else {
                    frmProd.btnNext.setVisibility(true);
                }
                frmProd.btnPrev.setVisibility(false);
                //kony.print(stack2.arr2[0].currentPage+"compare "+stack2.arr2[0].totalPages);
                frmProd.show();
            } else {
                kony.print("44");
                // getProducts(temp);
            }
        }
    } else {
        kony.application.dismissLoadingScreen();
        // The call failed because opstatus was not 0 so we'll alert the user and show that opststus
        kony.ui.Alert({
            message: "Service call failed with opstatus " + BestBuyResponse.opstatus,
            alertType: constants.ALERT_TYPE_ERROR,
            alertTitle: "Best Buy",
            yesLabel: "OK"
        }, {});
    }
}
/*function backStack2()
{
   if(stackTop>0)
  { //frm.    	
  	frmCat.segCat.widgetDataMap={lblCat:"CatNames"}; 
   	// Setting the data to the segment
  	//frmFoxNews.segNewsTitle.setVisibility(true);
  	kony.print("*");
  	kony.print(stackTop);
    kony.print(stack.arr[(1)]);
    kony.print("*======*");
    kony.print(stack.arr[(2)]);
     kony.print("*======*");
    kony.print(stack.arr[(stackTop)]);
    
    kony.print(stack.arr[stackTop].categories[0].CatNames);
    kony.print("*");
frmCat.segCat.setData(stack.arr[stackTop].categories);
    frmCat.show();
    
  }
}
*/