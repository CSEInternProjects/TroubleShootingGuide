function AS_Image_c0ed2d16bb154b1ab22816fea193fa55(eventobject, x, y) {
    return frmBack22.call(this);
}