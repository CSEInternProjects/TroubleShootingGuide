function AS_Image_b39ed763ff614c47be7faf5940242368(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}