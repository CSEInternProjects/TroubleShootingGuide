function AS_Button_cadf140863664b38a769505b35ab9f4d(eventobject) {
    return goNext.call(this);
}