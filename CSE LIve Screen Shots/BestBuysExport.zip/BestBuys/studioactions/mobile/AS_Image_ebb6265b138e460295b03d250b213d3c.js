function AS_Image_ebb6265b138e460295b03d250b213d3c(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}