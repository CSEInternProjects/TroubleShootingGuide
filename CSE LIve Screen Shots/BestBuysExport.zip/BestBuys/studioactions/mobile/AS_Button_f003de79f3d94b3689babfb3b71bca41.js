function AS_Button_f003de79f3d94b3689babfb3b71bca41(eventobject) {
    return goNext.call(this);
}