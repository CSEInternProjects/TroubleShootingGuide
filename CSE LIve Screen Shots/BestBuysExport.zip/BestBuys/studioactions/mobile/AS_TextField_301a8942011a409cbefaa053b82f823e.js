function AS_TextField_301a8942011a409cbefaa053b82f823e(eventobject, changedtext) {
    searchNow("Cats");
}