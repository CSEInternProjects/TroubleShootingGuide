function AS_Segment_02f51a4df32c4626b0482e7125537032(eventobject, sectionNumber, rowNumber) {
    return segRowTouchTwo.call(this);
}