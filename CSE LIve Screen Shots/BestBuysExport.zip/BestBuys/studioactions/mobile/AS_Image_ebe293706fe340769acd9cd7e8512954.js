function AS_Image_ebe293706fe340769acd9cd7e8512954(eventobject, x, y) {
    AS_Image_f16eb3fc58b4427aafed9a67fb211e46(eventobject, x, y);
}