function AS_Image_dd43e2d5ffbd4c4cb4cb6d5a4e8ff523(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}