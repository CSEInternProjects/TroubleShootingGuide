function AS_Image_db0f5fefa5b4402b9c2a498f56a562a6(eventobject, x, y) {
    return onClickBack3.call(this);
}