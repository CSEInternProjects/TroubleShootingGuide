function AS_Image_dd3f780cf96349638385a7b3d3f95a54(eventobject, x, y) {
    return onClickBack3.call(this);
}