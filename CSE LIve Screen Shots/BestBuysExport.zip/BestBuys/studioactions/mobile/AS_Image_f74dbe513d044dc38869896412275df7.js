function AS_Image_f74dbe513d044dc38869896412275df7(eventobject, x, y) {
    frmCat.flxMaster.imgBack.setVisibility(false);
    frmCat.flxCon1.setVisibility(true);
    frmCat.flxCon2.setVisibility(true);
    kony.print("value of flx container" + frmCat.flxCon1.zIndex);
    //frmCat.tbxSearch.setVisibility(true);
    //frmCat.tbxSearch.zIndex="5";
    //frmCat.tbxSearch.text="Search";
    //frmCat.btnGoSearch.setVisibility(true);
    //frmCat.btnGoSearch.zIndex="5";
    //frmCat.segCat.zIndex="2";
    kony.print("value of segment" + frmCat.segCat.zIndex);
    //frmCat.forceLayout();
    moveAnimation();
}