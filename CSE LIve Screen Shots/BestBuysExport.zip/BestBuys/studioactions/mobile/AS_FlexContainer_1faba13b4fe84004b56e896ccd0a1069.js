function AS_FlexContainer_1faba13b4fe84004b56e896ccd0a1069(eventobject, x, y) {
    frmPdetails.flxCon1.zIndex = "1";
    frmPdetails.flxCon1.setVisibility(false);
    frmPdetails.tbxSearch.setVisibility(false);
    frmPdetails.tbxSearch.zIndex = "1";
    frmPdetails.btnGoSearch.setVisibility(false);
    frmPdetails.btnGoSearch.zIndex = "1";
    frmPdetails.flxCon1.lblNoSearch.setVisibility(false);
    frmPdetails.forceLayout();
}