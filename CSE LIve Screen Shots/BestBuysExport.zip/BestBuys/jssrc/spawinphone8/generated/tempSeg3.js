function initializetempSeg3() {
    flxCat3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "50%",
        "id": "flxCat3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxCat3.setDefaultUnit(kony.flex.DP);
    var img2 = new kony.ui.Image2({
        "height": "72dp",
        "id": "img2",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "4dp",
        "width": "129dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblName = new kony.ui.Label({
        "id": "lblName",
        "isVisible": true,
        "left": "123dp",
        "maxHeight": "61dp",
        "skin": "CopyslLabel08598bd042d2142",
        "text": "Label",
        "top": "4dp",
        "width": "237dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblPrice2 = new kony.ui.Label({
        "id": "lblPrice2",
        "isVisible": true,
        "left": "129dp",
        "skin": "CopyslLabel012c7111725ec4d",
        "text": "Label",
        "top": "65dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblDesc = new kony.ui.Label({
        "id": "lblDesc",
        "isVisible": true,
        "left": "20dp",
        "maxHeight": "81dp",
        "skin": "CopyslLabel064ba004a3ef44d",
        "text": "Label",
        "top": "83dp",
        "width": "340dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var imgRat2 = new kony.ui.Image2({
        "height": "45dp",
        "id": "imgRat2",
        "isVisible": true,
        "left": "142dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "158dp",
        "width": "145dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var Rat = new kony.ui.Label({
        "id": "Rat",
        "isVisible": true,
        "left": "69dp",
        "skin": "CopyslLabel0b2744595d59446",
        "text": "Rating",
        "top": "172dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    flxCat3.add(img2, lblName, lblPrice2, lblDesc, imgRat2, Rat);
}