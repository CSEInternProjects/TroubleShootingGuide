function initializetempSeg4() {
    flxDetails = new kony.ui.FlexContainer({
        "clipBounds": true,
        "height": "220dp",
        "id": "flxDetails",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxDetails.setDefaultUnit(kony.flex.DP);
    var revTit = new kony.ui.Label({
        "id": "revTit",
        "isVisible": true,
        "left": "7dp",
        "maxHeight": "33dp",
        "skin": "CopyslLabel0adc4bff8a12e49",
        "text": "Label",
        "top": "2dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var revName = new kony.ui.Label({
        "id": "revName",
        "isVisible": true,
        "left": "7dp",
        "skin": "CopyslLabel0fe8d4784829944",
        "text": "Label",
        "top": "35dp",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var revRat = new kony.ui.Label({
        "id": "revRat",
        "isVisible": true,
        "left": "10dp",
        "skin": "CopyslLabel08c27c3e487c44c",
        "text": "Label",
        "top": "55dp",
        "width": "98%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var revDesc = new kony.ui.Label({
        "id": "revDesc",
        "isVisible": true,
        "maxHeight": "140dp",
        "skin": "CopyslLabel0994d97a116a640",
        "text": "Label",
        "top": "80dp",
        "width": "94%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    flxDetails.add(revTit, revName, revRat, revDesc);
}