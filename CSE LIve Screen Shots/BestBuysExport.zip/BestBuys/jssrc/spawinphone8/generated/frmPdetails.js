function addWidgetsfrmPdetails() {
    frmPdetails.setDefaultUnit(kony.flex.DP);
    var symb = new kony.ui.Image2({
        "centerX": "50%",
        "height": "36dp",
        "id": "symb",
        "isVisible": true,
        "left": "140dp",
        "skin": "slImage",
        "src": "bestbuylogo.png",
        "top": "5dp",
        "width": "65dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var back3 = new kony.ui.Image2({
        "height": "31dp",
        "id": "back3",
        "isVisible": true,
        "left": "0dp",
        "onTouchStart": AS_Image_db0f5fefa5b4402b9c2a498f56a562a6,
        "skin": "slImage",
        "src": "ic_menu_back.png",
        "top": "-32dp",
        "width": "45dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var segDetails = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "49.97%",
        "centerY": "36%",
        "data": [{
            "Rat": "Rating",
            "img2": "imagedrag.png",
            "imgRat2": "imagedrag.png",
            "lblDesc": "Label",
            "lblName": "Label",
            "lblPrice2": "Label"
        }],
        "groupCells": false,
        "height": "66.79%",
        "id": "segDetails",
        "isVisible": true,
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxCat3,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorRequired": true,
        "showScrollbars": false,
        "top": "7%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "Rat": "Rat",
            "flxCat3": "flxCat3",
            "img2": "img2",
            "imgRat2": "imgRat2",
            "lblDesc": "lblDesc",
            "lblName": "lblName",
            "lblPrice2": "lblPrice2"
        },
        "width": "99.96%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var segRev = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "revDesc": "Label",
            "revName": "Label",
            "revRat": "Label",
            "revTit": "Label"
        }, {
            "revDesc": "Label",
            "revName": "Label",
            "revRat": "Label",
            "revTit": "Label"
        }, {
            "revDesc": "Label",
            "revName": "Label",
            "revRat": "Label",
            "revTit": "Label"
        }],
        "groupCells": false,
        "height": "227dp",
        "id": "segRev",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxDetails,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "-160dp",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxDetails": "flxDetails",
            "revDesc": "revDesc",
            "revName": "revName",
            "revRat": "revRat",
            "revTit": "revTit"
        },
        "width": "363dp",
        "zIndex": 2
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var tbxSearch = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "height": "40dp",
        "id": "tbxSearch",
        "isVisible": false,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "10dp",
        "secureTextEntry": false,
        "skin": "slTextBox",
        "text": "Search",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "57dp",
        "width": "260dp",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var lblRev = new kony.ui.Label({
        "id": "lblRev",
        "isVisible": false,
        "left": "45dp",
        "skin": "CopyslLabel078f7f1f260ef45",
        "text": "No reviews found",
        "top": "-100dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    frmPdetails.add(symb, back3, segDetails, segRev, tbxSearch, lblRev);
};

function frmPdetailsGlobals() {
    frmPdetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmPdetails,
        "enabledForIdleTimeout": false,
        "id": "frmPdetails",
        "layoutType": kony.flex.FLOW_VERTICAL,
        "needAppMenu": true,
        "skin": "CopyslForm0a4570de32a5f4b"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmPdetails.info = {
        "kuid": "1d6098ceb3c443e3801083ec784904e4"
    };
};