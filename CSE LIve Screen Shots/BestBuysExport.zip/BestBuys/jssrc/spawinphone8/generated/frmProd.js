function addWidgetsfrmProd() {
    frmProd.setDefaultUnit(kony.flex.DP);
    var segCat2 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "centerX": "49.97%",
        "centerY": "52.35%",
        "data": [{
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }, {
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }, {
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }],
        "groupCells": false,
        "height": "405dp",
        "id": "segCat2",
        "isVisible": true,
        "needPageIndicator": true,
        "onRowClick": AS_Segment_02f51a4df32c4626b0482e7125537032,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxCat2,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxCat2": "flxCat2",
            "imgProd": "imgProd",
            "imgRating": "imgRating",
            "lblID": "lblID",
            "lblName": "lblName",
            "lblPrice": "lblPrice",
            "lblRat": "lblRat",
            "lblSaleNote": "lblSaleNote"
        },
        "width": "100.13%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var symb2 = new kony.ui.Image2({
        "centerX": "50%",
        "height": "36dp",
        "id": "symb2",
        "isVisible": true,
        "left": "140dp",
        "skin": "slImage",
        "src": "bestbuylogo.png",
        "top": "5dp",
        "width": "65dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var back2 = new kony.ui.Image2({
        "height": "31dp",
        "id": "back2",
        "isVisible": true,
        "left": "0dp",
        "onTouchStart": AS_Image_0ef8f5209c174765a6cac3742e8564bc,
        "skin": "slImage",
        "src": "ic_menu_back.png",
        "top": "8dp",
        "width": "45dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnNext = new kony.ui.Button({
        "centerX": "90%",
        "centerY": "93.50%",
        "focusSkin": "slButtonGlossRed",
        "height": "25dp",
        "id": "btnNext",
        "isVisible": true,
        "left": "300dp",
        "onClick": AS_Button_f003de79f3d94b3689babfb3b71bca41,
        "skin": "slButtonGlossBlue",
        "text": "next",
        "top": "506dp",
        "width": "65dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var btnPrev = new kony.ui.Button({
        "focusSkin": "slButtonGlossRed",
        "height": "26dp",
        "id": "btnPrev",
        "isVisible": true,
        "left": "8dp",
        "onClick": AS_Button_68ad07f5533e4c41b6a6622f7f6eb952,
        "skin": "slButtonGlossBlue",
        "text": "prev",
        "top": "505dp",
        "width": "66dp",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblPage = new kony.ui.Label({
        "id": "lblPage",
        "isVisible": true,
        "left": "132dp",
        "skin": "CopyslLabel027f55e923d074b",
        "text": "Label",
        "top": "508dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblPage2 = new kony.ui.Label({
        "id": "lblPage2",
        "isVisible": true,
        "left": "132dp",
        "skin": "CopyslLabel027f55e923d074b",
        "text": "Label",
        "top": "508dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    var lblDisp2 = new kony.ui.Label({
        "id": "lblDisp2",
        "isVisible": true,
        "left": "37dp",
        "skin": "CopyslLabel0b3b4c4a8a1d04f",
        "text": "Label",
        "top": "52dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false
    });
    frmProd.add(segCat2, symb2, back2, btnNext, btnPrev, lblPage, lblPage2, lblDisp2);
};

function frmProdGlobals() {
    frmProd = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmProd,
        "enabledForIdleTimeout": false,
        "id": "frmProd",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": true,
        "preShow": AS_Form_99cbc2b9675e4176ab41cf2ac1ad06c3,
        "skin": "CopyslForm015cc8557b96745"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmProd.info = {
        "kuid": "4bd2b06ab78f4ea892f4d461e040304d"
    };
};