function initializetempSeg4() {
    flxDetails = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "flxDetails",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "skin": "CopyslFbox0e4af0e43efea42"
    }, {}, {});
    flxDetails.setDefaultUnit(kony.flex.DP);
    var revTit = new kony.ui.Label({
        "id": "revTit",
        "isVisible": true,
        "left": "7dp",
        "skin": "CopyslLabel0adc4bff8a12e49",
        "text": "Label",
        "top": "2dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var revName = new kony.ui.Label({
        "id": "revName",
        "isVisible": true,
        "left": "7dp",
        "skin": "CopyslLabel0fe8d4784829944",
        "text": "Label",
        "top": "0dp",
        "width": "80%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var imgRat = new kony.ui.Image2({
        "height": "31dp",
        "id": "imgRat",
        "isVisible": true,
        "left": "2dp",
        "skin": "slImage",
        "src": "ratings_star_5.png",
        "top": "0dp",
        "width": "170dp",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var revDesc = new kony.ui.Label({
        "id": "revDesc",
        "isVisible": true,
        "left": "1dp",
        "skin": "CopyslLabel0994d97a116a640",
        "text": "Label",
        "top": "0dp",
        "width": "94%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    flxDetails.add(revTit, revName, imgRat, revDesc);
}