function addWidgetsfrmProd() {
    frmProd.setDefaultUnit(kony.flex.DP);
    var segCat2 = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblPriceRed": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }, {
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblPriceRed": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }, {
            "imgProd": "imagedrag.png",
            "imgRating": "imagedrag.png",
            "lblID": "Label",
            "lblName": "Label",
            "lblPrice": "Label",
            "lblPriceRed": "Label",
            "lblRat": "Label",
            "lblSaleNote": "Label"
        }],
        "groupCells": false,
        "height": "72%",
        "id": "segCat2",
        "isVisible": true,
        "left": "0dp",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_02f51a4df32c4626b0482e7125537032,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxCat2,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "18%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "FlexContainer060f5d758cc1445": "FlexContainer060f5d758cc1445",
            "flxCat2": "flxCat2",
            "imgProd": "imgProd",
            "imgRating": "imgRating",
            "lblID": "lblID",
            "lblName": "lblName",
            "lblPrice": "lblPrice",
            "lblPriceRed": "lblPriceRed",
            "lblRat": "lblRat",
            "lblSaleNote": "lblSaleNote"
        },
        "width": "100.13%",
        "zIndex": 1
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE,
        "enableDictionary": false,
        "indicator": constants.SEGUI_ROW_SELECT,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "showProgressIndicator": true
    });
    var lblDisp2 = new kony.ui.Label({
        "height": "8%",
        "id": "lblDisp2",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0b3b4c4a8a1d04f",
        "text": "Label",
        "top": "10%",
        "width": "99.07%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var kmd895213a0c347689d6395896235de8f = new kony.ui.FlexContainer({
        "clipBounds": true,
        "isMaster": true,
        "height": "10%",
        "id": "flxMaster",
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "top": "0%",
        "width": "100%",
        "zIndex": 1,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "isVisible": true,
        "skin": "CopyslFbox07e41b77d98ba4c"
    }, {}, {});
    kmd895213a0c347689d6395896235de8f.setDefaultUnit(kony.flex.DP);
    var km6442394f8c4460abc0ed0c2104bca69 = new kony.ui.Image2({
        "centerX": "48.01%",
        "centerY": "48.31%",
        "height": "75%",
        "id": "imgBestBuy",
        "left": "140%",
        "src": "bestbuylogo.png",
        "top": "9%",
        "width": "31%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var kmd8985ec40fa443d84cc5d628fcca464 = new kony.ui.Label({
        "bottom": "0dp",
        "centerX": "50.00%",
        "centerY": "96.59%",
        "height": "3%",
        "id": "lblDivider",
        "left": "0dp",
        "text": "Label",
        "textStyle": {},
        "width": "100%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel07ba66cdf3edf46",
        "top": "7%"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var kmdab73fa7fc7438c84a372ec6f932711 = new kony.ui.Image2({
        "height": "78%",
        "id": "imgBack",
        "left": "1%",
        "onTouchEnd": AS_Image_c396a07a1da8497dadedfdffc0062677,
        "onTouchStart": AS_Image_c0ed2d16bb154b1ab22816fea193fa55,
        "src": "ic_menu_back.png",
        "top": "4%",
        "width": "18%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var kmd464345899041009bdfe8078be474b9 = new kony.ui.Image2({
        "height": "54dp",
        "id": "btnSearch",
        "left": "294dp",
        "onTouchEnd": AS_Image_eef66dc4e5c44ba4aaae797884b84d01,
        "src": "ic_menu_search.png",
        "top": "9%",
        "width": "80dp",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage022f63153460143"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    kmd895213a0c347689d6395896235de8f.add(km6442394f8c4460abc0ed0c2104bca69, kmd8985ec40fa443d84cc5d628fcca464, kmdab73fa7fc7438c84a372ec6f932711, kmd464345899041009bdfe8078be474b9);
    var flxNextPrev = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxNextPrev",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "90%",
        "width": "100%",
        "zIndex": 1
    }, {}, {});
    flxNextPrev.setDefaultUnit(kony.flex.DP);
    var btnNext = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "60%",
        "id": "btnNext",
        "isVisible": true,
        "onClick": AS_Button_cadf140863664b38a769505b35ab9f4d,
        "right": "3dp",
        "skin": "btnSkin",
        "text": "Next>>",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    var lblPage = new kony.ui.Label({
        "centerY": "50%",
        "id": "lblPage",
        "isVisible": true,
        "skin": "CopyslLabel027f55e923d074b",
        "text": "Label",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var lblPage2 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "50%",
        "id": "lblPage2",
        "isVisible": true,
        "skin": "CopyslLabel027f55e923d074b",
        "text": "Label",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var btnPrev = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "60%",
        "id": "btnPrev",
        "isVisible": true,
        "left": "3dp",
        "onClick": AS_Button_f33b750f1f684715a6f0d2e5a23e0230,
        "skin": "btnSkin",
        "text": "<<Prev",
        "top": "18%",
        "width": "20%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "showProgressIndicator": true
    });
    flxNextPrev.add(btnNext, lblPage, lblPage2, btnPrev);
    frmProd.add(segCat2, lblDisp2, kmd895213a0c347689d6395896235de8f, flxNextPrev);
};

function frmProdGlobals() {
    frmProd = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmProd,
        "enabledForIdleTimeout": false,
        "id": "frmProd",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "preShow": AS_Form_99cbc2b9675e4176ab41cf2ac1ad06c3,
        "skin": "CopyslForm015cc8557b96745"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "configureExtendBottom": false,
        "configureExtendTop": false,
        "configureStatusBarStyle": false,
        "footerOverlap": false,
        "formTransparencyDuringPostShow": "100",
        "headerOverlap": false,
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
        "needsIndicatorDuringPostShow": false,
        "retainScrollPosition": false,
        "titleBar": true,
        "titleBarConfig": {
            "renderTitleText": true,
            "prevFormTitle": false,
            "titleBarLeftSideView": "button",
            "labelLeftSideView": "Back",
            "titleBarRightSideView": "button",
            "labelRightSideView": "Edit"
        },
        "titleBarSkin": "slTitleBar"
    });
};