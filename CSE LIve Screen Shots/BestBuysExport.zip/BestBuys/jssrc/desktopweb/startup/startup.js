//startup.js file
var appConfig = {
    appId: "BestBuys",
    appName: "BestBuys",
    appVersion: "1.0.0",
    platformVersion: null,
    serverIp: "10.10.34.47",
    serverPort: "80",
    secureServerPort: "443",
    isturlbase: "http://KH9331.kitspl.com:8080/services",
    isMFApp: true,
    appKey: "dad4b26617dad379216713c91c2fc8b0",
    appSecret: "df05ae008d19e1eb54402bcb6f64f54",
    serviceUrl: "http://KH9331.kitspl.com:8080/authService/100000002/appconfig",
    svcDoc: {
        "appId": "10942dd0-ebc3-4f29-b9e0-d602b0e8f8f7",
        "baseId": "3dd48ead-3199-4470-b354-44bd84fab6b7",
        "name": "BestBuy",
        "selflink": "http://KH9331.kitspl.com:8080/authService/100000002/appconfig",
        "login": [{
            "type": "basic",
            "prov": "userstore",
            "url": "http://KH9331.kitspl.com:8080/authService/100000002",
            "alias": "userstore"
        }],
        "integsvc": {
            "categories": "http://KH9331.kitspl.com:8080/services/categories"
        },
        "reportingsvc": {
            "custom": "http://KH9331.kitspl.com:8080/services/CMS",
            "session": "http://KH9331.kitspl.com:8080/services/IST"
        },
        "Webapp": {
            "url": "http://KH9331.kitspl.com:8080/BestBuys"
        },
        "services_meta": {
            "categories": {
                "version": "1.0",
                "url": "http://KH9331.kitspl.com:8080/services/categories",
                "type": "integsvc"
            }
        }
    },
    svcDocRefresh: false,
    svcDocRefreshTimeSecs: -1,
    eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"],
    url: "http://KH9331.kitspl.com:8080/BestBuys/MWServlet",
    secureurl: "http://KH9331.kitspl.com:8080/BestBuys/MWServlet",
    middlewareContext: "BestBuys"
};
sessionID = "";

function appInit(params) {
    skinsInit();
    frmCseGlobals();
    setAppBehaviors();
};

function setAppBehaviors() {
    kony.application.setApplicationBehaviors({
        applyMarginPaddingInBCGMode: false,
        adherePercentageStrictly: true,
        retainSpaceOnHide: true,
        APILevel: 7200
    })
};

function themeCallBack() {
    initializeGlobalVariables();
    kony.application.setApplicationInitializationEvents({
        init: appInit,
        showstartupform: function() {
            frmCse.show();
        }
    });
};

function loadResources() {
    kony.theme.packagedthemes(
        ["default"]);
    globalhttpheaders = {};
    sdkInitConfig = {
        "appConfig": appConfig,
        "isMFApp": appConfig.isMFApp,
        "appKey": appConfig.appKey,
        "appSecret": appConfig.appSecret,
        "serviceUrl": appConfig.serviceUrl,
        eventTypes: ["FormEntry", "ServiceRequest", "Error", "Crash"]
    }
    kony.setupsdks(sdkInitConfig, onSuccessSDKCallBack, onSuccessSDKCallBack);
};

function onSuccessSDKCallBack() {
    spaAPM && spaAPM.startTracking();
    kony.theme.setCurrentTheme("default", themeCallBack, themeCallBack);
}

function initializeApp() {
    kony.application.setApplicationMode(constants.APPLICATION_MODE_NATIVE);
    //If default locale is specified. This is set even before any other app life cycle event is called.
    loadResources();
};