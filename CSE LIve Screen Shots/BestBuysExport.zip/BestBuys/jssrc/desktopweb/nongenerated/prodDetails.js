//Type your code here
function segRowTouchTwo() {
    kony.print("in 2");
    var selectedRowData = frmProd.segCat2.selectedItems[0]["pId"];
    var headers = {};
    var get = "getProductDetails";
    data = {
        "pId": selectedRowData
    };
    kony.print(11);
    mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallback5, getNewsErrorCallback);
}

function getNewsSuccessCallback5(productDetails) {
    var q = "";
    backUp = productDetails.product[0].pSku;
    kony.print(productDetails);
    kony.print(productDetails + "first time*******************");
    //frmPdetails.flxPdetails.lblName.text=productDetails.product[0].pName; 
    if (productDetails.product[0].pSaleStatus === "false") {
        q = "$";
        q = q.concat(productDetails.product[0].pRegPrice);
        productDetails.product[0].setPrice = q;
    } else {
        q = "Onsale $";
        q = q.concat(productDetails.product[0].pSalePrice);
        productDetails.product[0].setPrice = q;
        //frmPdetails.flxPdetails.lblPrice2=productDetails.product[0].pSalePrice;     
    }
    //frmPdetails.flxPdetails.img2=productDetails.product[0].pImg;
    //frmPdetails.flxPdetails.lblDesc.text=productDetails.product[0].pDesc;
    if ((productDetails.product[0].pAvgReview >= 0) && (productDetails.product[0].pAvgReview < 1)) {
        productDetails.product[0].img = "ratings_star_1.png";
    } else if ((productDetails.product[0].pAvgReview >= 1) && (productDetails.product[0].pAvgReview < 2)) {
        productDetails.product[0].img = "ratings_star_2.png";
    } else if ((productDetails.product[0].pAvgReview >= 2) && (productDetails.product[0].pAvgReview < 3)) {
        productDetails.product[0].img = "ratings_star_3.png";
    } else if ((productDetails.product[0].pAvgReview >= 3) && (productDetails.product[0].pAvgReview < 4)) {
        productDetails.product[0].img = "ratings_star_4.png";
    } else if ((productDetails.product[0].pAvgReview >= 4) && (productDetails.product[0].pAvgReview < 5)) {
        productDetails.product[0].img = "ratings_star_5.png";
    }
    productDetails.product[0].Rating = "Rating:";
    productDetails.product[0].Rating += productDetails.product[0].pAvgReview;
    productDetails.product[0].More = "more...";
    //frmPdetails.flxPdetails.imgRat2=productDetails.product[0].img;
    //frm.segCat2.widgetDataMap={lblID:"pId",lblRat:"Tex",imgProd:"pImage",imgRating:"img",lblName:"pName",lblPrice:"pSalePrice"};         
    //      frmProd.segCat2.setData(stack2.arr2[stackTop2].productList);
    frmPdetails.segDetails.widgetDataMap = {
        RTxtMore: "More",
        Rat: "Rating",
        img2: "pImg",
        lblName: "pName",
        lblPrice2: "setPrice",
        lblDesc: "pDesc",
        imgRat2: "img"
    };
    frmPdetails.segDetails.setData(productDetails.product);
    reviewCall(backUp);
    //frmPdetails.segDetails.centerX="50%";
    //frmPdetails.segDetails.centerY="50%";
    //frmPdetails.forceLayout();
    frmPdetails.show();
    kony.print(productDetails);
}

function reviewCall(backUp) {
    var headers = {};
    var get = "getProductReviews";
    data = {
        "sku": backUp
    };
    //kony.print(11);
    mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallback6, getNewsErrorCallback6);
}

function getNewsSuccessCallback6(rev) {
    kony.print(rev);
    kony.print("now we are implementing review object");
    //kony.print(rev.reviews[0].reviewer); 
    if (rev !== null && rev.opstatus === 0) {
        // Checking to make sure we DO have results
        if (rev.reviews !== null) {
            // Making sure we have at least 1 article returned
            if (rev.reviews.length > 0) {
                kony.print(rev.reviews[0].reviewer);
                for (var i = 0; i < rev.reviews.length; i++) {
                    rev.reviews[i].reviewTitle = "Opinion : ".concat(rev.reviews[i].reviewTitle);
                    rev.reviews[i].reviewer = "UserName: ".concat(rev.reviews[i].reviewer);
                    if ((rev.reviews[i].reviewRating >= 0) && (rev.reviews[i].reviewRating < 1)) {
                        rev.reviews[i].img = "ratings_star_1.png";
                    } else if ((rev.reviews[i].reviewRating >= 1) && (rev.reviews[i].reviewRating < 2)) {
                        rev.reviews[i].img = "ratings_star_2.png";
                    } else if ((rev.reviews[i].reviewRating >= 2) && (rev.reviews[i].reviewRating < 3)) {
                        rev.reviews[i].img = "ratings_star_3.png";
                    } else if ((rev.reviews[i].reviewRating >= 3) && (rev.reviews[i].reviewRating < 4)) {
                        rev.reviews[i].img = "ratings_star_4.png";
                    } else if ((rev.reviews[i].reviewRating >= 4) && (rev.reviews[i].reviewRating <= 5)) {
                        rev.reviews[i].img = "ratings_star_5.png";
                    }
                    //rev.reviews[i].reviewRating="Rating is : ".concat(rev.reviews[i].reviewRating);
                    rev.reviews[i].reviewComment = "View : ".concat(rev.reviews[i].reviewComment);
                }
                frmPdetails.lblRevCount2.text = "Number of Reviews: ";
                frmPdetails.lblRevCount2.text += rev.reviewCount;
                //frmPdetails.lblRevCount.centerX="10%";
                //frmPdetails.lblRevCount.centerY="53%";
                //frmPdetails.forceLayout();
                //frmPdetails.lblRevCount.setVisibility(true);
                frmPdetails.lblRevCount2.setVisibility(true);
                frmPdetails.segRev.widgetDataMap = {
                    revTit: "reviewTitle",
                    revName: "reviewer",
                    revDesc: "reviewComment",
                    imgRat: "img"
                };
                frmPdetails.segRev.setData(rev.reviews);
                frmPdetails.forceLayout();
            } else {
                kony.print("nothing to print");
                frmPdetails.lblRevCount.setVisibility(false);
                frmPdetails.lblRevCount2.setVisibility(false);
                frmPdetails.segRev.setVisibility(false);
                frmPdetails.lblRev.setVisibility(true);
                frmPdetails.forceLayout();
            }
        }
    }
}

function getNewsErrorCallback6() {
    kony.print("nothing to print and its error call back 6");
    frmPdetails.lblRevCount.setVisibility(false);
    frmPdetails.lblRevCount2.setVisibility(false);
    frmPdetails.segRev.setVisibility(false);
    frmPdetails.lblRev.setVisibility(true);
    frmPdetails.forceLayout();
}

function onClickBack3() {
    frmPdetails.lblRevCount.setVisibility(false);
    frmPdetails.lblRevCount2.setVisibility(false);
    frmPdetails.destroy();
    if (searchActive === 0) {
        k = stack2.arr2[stackTop2].currentPage;
        frmPdetails.segRev.setVisibility(true);
        frmPdetails.lblRev.setVisibility(false);
        frmPdetails.forceLayout();
        var dollerSign = "";
        var w = "page";
        w = w.concat(stack2.arr2[stackTop2].currentPage);
        w = w.concat("of");
        w = w.concat(stack2.arr2[stackTop2].totalPages);
        frmProd.lblPage.text = w;
        frmProd.lblPage2.text = w;
        for (i = 0; i < stack2.arr2[stackTop2].productList.length; i++) {
            stack2.arr2[stackTop2].productList[i].pSalePrice = dollerSign.concat(stack2.arr2[stackTop2].productList[i].pSalePrice);
            kony.print(i);
            stack2.arr2[stackTop2].productList[i].Tex = "Rating";
            if ((stack2.arr2[stackTop2].productList[i].pAvgReview >= 0) && (stack2.arr2[stackTop2].productList[i].pAvgReview < 1)) {
                stack2.arr2[stackTop2].productList[i].img = "ratings_star_1.png";
            } else if ((stack2.arr2[stackTop2].productList[i].pAvgReview >= 1) && (stack2.arr2[stackTop2].productList[i].pAvgReview < 2)) {
                stack2.arr2[stackTop2].productList[i].img = "ratings_star_2.png";
            } else if ((stack2.arr2[stackTop2].productList[i].pAvgReview >= 2) && (stack2.arr2[stackTop2].productList[i].pAvgReview < 3)) {
                stack2.arr2[stackTop2].productList[i].img = "ratings_star_3.png";
            } else if ((stack2.arr2[stackTop2].productList[i].pAvgReview >= 3) && (stack2.arr2[stackTop2].productList[i].pAvgReview < 4)) {
                stack2.arr2[stackTop2].productList[i].img = "ratings_star_4.png";
            } else if ((stack2.arr2[stackTop2].productList[i].pAvgReview >= 4) && (stack2.arr2[stackTop2].productList[i].pAvgReview < 5)) {
                stack2.arr2[stackTop2].productList[i].img = "ratings_star_5.png";
            }
        }
        frmProd.segCat2.widgetDataMap = {
            lblSaleNote: "saleNote",
            lblID: "pId",
            lblRat: "Tex",
            imgProd: "pImage",
            imgRating: "img",
            lblName: "pName",
            lblPrice: "pSalePrice1",
            lblPriceRed: "pSalePrice2"
        };
        frmProd.segCat2.setData(stack2.arr2[stackTop2].productList);
        frmProd.show();
        if (k === stack2.arr2[stackTop2].totalPages) {
            frmProd.btnNext.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        } else {
            frmProd.btnNext.setVisibility(true);
        }
        //kony.print("test for K value"+k); 
        if (k == 1) {
            kony.print("now test for K value2 " + k);
            frmProd.btnPrev.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        } else {
            kony.print(" now test for K value3" + k);
            frmProd.btnPrev.setVisibility(true);
        }
        if (k == 1) {
            // kony.print("test for K value2"+k);
            frmProd.btnPrev.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        }
    } else if (searchActive == 1) {
        sPageNo = stack3.arr3[stackTop3].currentPage;
        frmPdetails.segRev.setVisibility(true);
        frmPdetails.lblRev.setVisibility(false);
        frmPdetails.forceLayout();
        frmPdetails.segRev.setVisibility(true);
        frmPdetails.lblRev.setVisibility(false);
        var dollerSign2 = "";
        var w2 = "page";
        w2 = w2.concat(stack3.arr3[stackTop3].currentPage);
        w2 = w2.concat("of");
        w2 = w2.concat(stack3.arr3[stackTop3].totalPages);
        frmProd.lblPage.text = w2;
        frmProd.lblPage2.text = w2;
        for (i = 0; i < stack3.arr3[stackTop3].productList.length; i++) {
            stack3.arr3[stackTop3].productList[i].pSalePrice = dollerSign2.concat(stack3.arr3[stackTop3].productList[i].pSalePrice);
            //kony.print(i);
            stack3.arr3[stackTop3].productList[i].Tex = "Rating";
            if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 0) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 1)) {
                stack3.arr3[stackTop3].productList[i].img = "ratings_star_1.png";
            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 1) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 2)) {
                stack3.arr3[stackTop3].productList[i].img = "ratings_star_2.png";
            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 2) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 3)) {
                stack3.arr3[stackTop3].productList[i].img = "ratings_star_3.png";
            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 3) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 4)) {
                stack3.arr3[stackTop3].productList[i].img = "ratings_star_4.png";
            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 4) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 5)) {
                stack3.arr3[stackTop3].productList[i].img = "ratings_star_5.png";
            }
        }
        frmProd.segCat2.widgetDataMap = {
            lblSaleNote: "saleNote",
            imgProd: "pImage",
            lblID: "pId",
            lblRat: "Tex",
            imgRating: "img",
            lblName: "pName",
            lblPrice: "pSalePrice1",
            lblPriceRed: "pSalePrice2"
        };
        frmProd.segCat2.setData(stack3.arr3[stackTop3].productList);
        frmProd.show();
        if (sPageNo === stack3.arr3[stackTop3].totalPages) {
            frmProd.btnNext.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        } else {
            frmProd.btnNext.setVisibility(true);
        }
        //kony.print("test for K value"+k); 
        if (sPageNo == 1) {
            kony.print("now test for K value2 " + k);
            frmProd.btnPrev.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        } else {
            kony.print(" now test for K value3" + k);
            frmProd.btnPrev.setVisibility(true);
        }
        if (sPageNo == 1) {
            // kony.print("test for K value2"+k);
            frmProd.btnPrev.setVisibility(false);
            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
        }
    }
}