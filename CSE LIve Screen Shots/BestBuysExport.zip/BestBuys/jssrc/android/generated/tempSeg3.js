function initializetempSeg3() {
    flxCat3 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "flxCat3",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "skin": "slFbox"
    }, {}, {});
    flxCat3.setDefaultUnit(kony.flex.DP);
    var img2 = new kony.ui.Image2({
        "height": "38.54%",
        "id": "img2",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "11dp",
        "width": "32.41%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var lblDesc = new kony.ui.Label({
        "id": "lblDesc",
        "isVisible": true,
        "left": "1%",
        "skin": "CopyslLabel0eb8d6feab6d546",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "68%",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var flxLblVer = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
        "clipBounds": true,
        "id": "flxLblVer",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "34%",
        "skin": "slFbox",
        "top": "2%",
        "width": "67.91%",
        "zIndex": 1
    }, {}, {});
    flxLblVer.setDefaultUnit(kony.flex.DP);
    var lblName = new kony.ui.Label({
        "id": "lblName",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel08598bd042d2142",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var lblPrice2 = new kony.ui.Label({
        "id": "lblPrice2",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel012c7111725ec4d",
        "text": "Label",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var Rat = new kony.ui.Label({
        "id": "Rat",
        "isVisible": true,
        "left": "0dp",
        "skin": "CopyslLabel0b2744595d59446",
        "text": "Rating",
        "textStyle": {
            "letterSpacing": 0,
            "strikeThrough": false
        },
        "top": "0dp",
        "width": "100%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "textCopyable": false
    });
    var imgRat2 = new kony.ui.Image2({
        "id": "imgRat2",
        "isVisible": true,
        "left": "0dp",
        "skin": "slImage",
        "src": "imagedrag.png",
        "top": "2dp",
        "width": "60.03%",
        "zIndex": 1
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxLblVer.add(lblName, lblPrice2, Rat, imgRat2);
    var RTxtMore = new kony.ui.RichText({
        "id": "RTxtMore",
        "isVisible": true,
        "left": "23dp",
        "skin": "CopyslRichText0094448e5a7524a",
        "text": "more...\n",
        "top": "110dp",
        "width": "25.00%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCat3.add(img2, lblDesc, flxLblVer, RTxtMore);
}