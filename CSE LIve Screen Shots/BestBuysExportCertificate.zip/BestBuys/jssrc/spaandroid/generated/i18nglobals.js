kony.globals["appid"] = "BestBuyNew";
kony.globals["locales"] = [];