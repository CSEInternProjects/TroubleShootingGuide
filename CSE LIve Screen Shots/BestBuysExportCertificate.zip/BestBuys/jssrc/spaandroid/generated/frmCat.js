function addWidgetsfrmCat() {
    frmCat.setDefaultUnit(kony.flex.DP);
    var flxCon1 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "80%",
        "id": "flxCon1",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "CopyslFbox08333b29d7f324f",
        "top": "20%",
        "width": "100%",
        "zIndex": 3
    }, {}, {});
    flxCon1.setDefaultUnit(kony.flex.DP);
    var lblNoSearch = new kony.ui.Label({
        "id": "lblNoSearch",
        "isVisible": false,
        "left": "43dp",
        "skin": "CopyslLabel0c4a4a47bf13144",
        "text": "Search not found",
        "top": "343dp",
        "width": kony.flex.USE_PREFFERED_SIZE,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    flxCon1.add(lblNoSearch);
    var km91750977fb74b58b880a19e9e7689ad = new kony.ui.FlexContainer({
        "clipBounds": true,
        "isMaster": true,
        "height": "10%",
        "id": "flxMaster",
        "layoutType": kony.flex.FREE_FORM,
        "left": "0%",
        "top": "0%",
        "width": "100%",
        "zIndex": 3,
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "isVisible": true,
        "skin": "CopyslFbox07e41b77d98ba4c"
    }, {}, {});
    km91750977fb74b58b880a19e9e7689ad.setDefaultUnit(kony.flex.DP);
    var km36cd92bacb84bf9b9c336ae361c77d0 = new kony.ui.Image2({
        "centerX": "50%",
        "centerY": "50%",
        "height": "80%",
        "id": "imgBestBuy",
        "left": 0,
        "src": "bestbuylogo.png",
        "top": "0dp",
        "width": "31%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var kmfa42015b760472682f0fd14ca6153e5 = new kony.ui.Label({
        "centerX": "50%",
        "centerY": "96%",
        "height": "3%",
        "id": "lblDivider",
        "left": "0dp",
        "text": "Label",
        "textStyle": {},
        "top": "7%",
        "width": "100%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslLabel07ba66cdf3edf46"
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var km684f828b9d74369817a3a5402e9c52a = new kony.ui.Image2({
        "height": "93%",
        "id": "imgBack",
        "left": "0%",
        "onTouchEnd": AS_Image_b39ed763ff614c47be7faf5940242368,
        "onTouchStart": AS_Image_e9be2253e34243e396bf5e860105f7e0,
        "src": "ic_menu_back.png",
        "top": "0%",
        "width": "20%",
        "zIndex": 1,
        "isVisible": true,
        "skin": "CopyslImage"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var km6046b83b00b48a2bd5d0259afb8cdb0 = new kony.ui.Image2({
        "height": "93%",
        "id": "btnSearch",
        "onTouchStart": AS_Image_f74dbe513d044dc38869896412275df7,
        "right": "0%",
        "src": "ic_menu_search.png",
        "top": "0%",
        "width": "25%",
        "zIndex": 1,
        "isVisible": true,
        "left": "294dp",
        "onTouchEnd": AS_Image_f16eb3fc58b4427aafed9a67fb211e46,
        "skin": "CopyslImage022f63153460143"
    }, {
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    km91750977fb74b58b880a19e9e7689ad.add(km36cd92bacb84bf9b9c336ae361c77d0, kmfa42015b760472682f0fd14ca6153e5, km684f828b9d74369817a3a5402e9c52a, km6046b83b00b48a2bd5d0259afb8cdb0);
    var FlexContainer0dd544890451d43 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "100%",
        "id": "FlexContainer0dd544890451d43",
        "isVisible": true,
        "layoutType": kony.flex.FLOW_VERTICAL,
        "left": "0%",
        "skin": "CopyslFbox0c8702e9263394d",
        "top": "0%",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    FlexContainer0dd544890451d43.setDefaultUnit(kony.flex.DP);
    var flxCon2 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "10%",
        "id": "flxCon2",
        "isVisible": false,
        "layoutType": kony.flex.FREE_FORM,
        "left": "0dp",
        "skin": "slFbox",
        "top": "0dp",
        "width": "100%",
        "zIndex": 2
    }, {}, {});
    flxCon2.setDefaultUnit(kony.flex.DP);
    var tbxSearch = new kony.ui.TextBox2({
        "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
        "centerY": "50%",
        "height": "40dp",
        "id": "tbxSearch",
        "isVisible": true,
        "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
        "left": "2%",
        "onDone": AS_TextField_f41aabdff7404e958275b9882b76e03a,
        "placeholder": "Search",
        "secureTextEntry": false,
        "skin": "CopyslTextBox09995e7ceff744b",
        "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
        "top": "0dp",
        "width": "67%",
        "zIndex": 1
    }, {
        "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [3, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "autoComplete": false,
        "autoCorrect": false
    });
    var btnGoSearch = new kony.ui.Button({
        "centerY": "50%",
        "focusSkin": "slButtonGlossRed",
        "height": "50dp",
        "id": "btnGoSearch",
        "isVisible": true,
        "left": "70%",
        "onClick": AS_Button_je1d609c4ce5411dba51980d9d598ab9,
        "skin": "CopyslButtonGlossBlue0a460198bf81b43",
        "text": "Cancle",
        "top": "0dp",
        "width": "27%",
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    flxCon2.add(tbxSearch, btnGoSearch);
    var lblDisp = new kony.ui.Label({
        "height": "10%",
        "id": "lblDisp",
        "isVisible": true,
        "left": "0%",
        "skin": "CopyslLabel048e11b46c77d49",
        "text": "Home",
        "top": "10%",
        "width": "100%",
        "zIndex": 2
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "renderAsAnchor": false,
        "textCopyable": false
    });
    var segCat = new kony.ui.SegmentedUI2({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "data": [{
            "lblCat": "Label"
        }, {
            "lblCat": "Label"
        }, {
            "lblCat": "Label"
        }],
        "groupCells": false,
        "height": "80%",
        "id": "segCat",
        "isVisible": true,
        "left": "-0.01%",
        "needPageIndicator": true,
        "onRowClick": AS_Segment_c6ab25160fdf4c9ea36806df8252f353,
        "pageOffDotImage": "pageoffdot.png",
        "pageOnDotImage": "pageondot.png",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": flxCat,
        "scrollingEvents": {},
        "sectionHeaderSkin": "sliPhoneSegmentHeader",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "top": "0.00%",
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "flxCat": "flxCat",
            "lblCat": "lblCat"
        },
        "width": "100%",
        "zIndex": 2
    }, {
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    FlexContainer0dd544890451d43.add(flxCon2, lblDisp, segCat);
    frmCat.add(flxCon1, km91750977fb74b58b880a19e9e7689ad, FlexContainer0dd544890451d43);
};

function frmCatGlobals() {
    frmCat = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCat,
        "enabledForIdleTimeout": false,
        "id": "frmCat",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "postShow": AS_Form_dd38d2a4a5104d608743a4f107c2c0e8,
        "preShow": AS_Form_192cf810787e4c31afdc59dc734c116f,
        "skin": "CopyslForm015cc8557b96745"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
};