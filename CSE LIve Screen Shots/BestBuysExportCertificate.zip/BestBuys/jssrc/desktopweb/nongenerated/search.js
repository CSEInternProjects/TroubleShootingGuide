//Type your code here
function searchNow(note) {
    var searchText;
    track = note;
    if (note === ("Cats")) searchText = frmCat.tbxSearch.text;
    else if (note === ("Prod")) searchText = frmProd.tbxSearch.text;
    else if (note === ("Pdetails")) searchText = frmPdetails.tbxSearch.text;
    var headers = {};
    var get = "productSearch";
    data = {
        "keyword": searchText,
        "pageNo": sPageNo
    };
    mySearch = searchText;
    kony.print(11);
    mobileFabricConfiguration.integrationObj.invokeOperation(get, headers, data, getNewsSuccessCallbackSearch, getNewsErrorCallback);
}

function getNewsSuccessCallbackSearch(searchDetails) {
    kony.print(searchDetails);
    kony.print("testing on search result");
    var x, y;
    x = parseInt(searchDetails.totalPages);
    y = parseInt(searchDetails.currentPage);
    if (y > x) {
        if (track === ("Cats")) {
            kony.print("notttt");
            frmCat.flxCon1.lblNoSearch.setVisibility(true);
            //frmCat.flxCon1.lblNoSearch.zIndex="5";
            frmCat.forceLayout();
        }
        if (track === ("Prod")) frmProd.flxCon1.lblNoSearch.setVisibility(true);
        if (track === ("Pdetails")) frmPdetails.flxCon1.lblNoSearch.setVisibility(true);
    } else {
        if (searchAgain === 0) {
            frmProd.lblPage2.setVisibility(false);
            searchActive = 1;
            //searchAgain=1;
            stack3.arr3.push(searchDetails);
            //stack3.arr3.push(searchDetails);
            //kony.print("sssssssssssssss");
            //kony.print(searchDetails);	
            kony.print(searchDetails + "aaaasasasas");
            var i;
            kony.print("I am Here");
            var dollerSign = "price: $";
            if (stack3.arr3[stackTop3] !== null) {
                // Checking to make sure we DO have results
                if (stack3.arr3[stackTop3].productList !== null) {
                    // Making sure we have at least 1 article returned
                    if (stack3.arr3[stackTop3].productList.length > 0) {
                        for (i = 0; i < stack3.arr3[stackTop3].productList.length; i++) {
                            if (stack3.arr3[stackTop3].productList[i].pSaleStatus === true) {
                                stack3.arr3[stackTop3].productList[i].saleNote = "                                   On sale!!";
                            } else {
                                stack3.arr3[stackTop3].productList[i].saleNote = "";
                            }
                            kony.print(i);
                            stack3.arr3[stackTop3].productList[i].pSalePrice = dollerSign.concat(stack3.arr3[stackTop3].productList[i].pSalePrice);
                            kony.print(i);
                            stack3.arr3[stackTop3].productList[i].Tex = "Rating";
                            if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 0) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 1)) {
                                stack3.arr3[stackTop3].productList[i].img = "ratings_star_1.png";
                            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 1) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 2)) {
                                stack3.arr3[stackTop3].productList[i].img = "ratings_star_2.png";
                            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 2) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 3)) {
                                stack3.arr3[stackTop3].productList[i].img = "ratings_star_3.png";
                            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 3) && (stack3.arr3[stackTop3].productList[i].pAvgRating < 4)) {
                                stack3.arr3[stackTop3].productList[i].img = "ratings_star_4.png";
                            } else if ((stack3.arr3[stackTop3].productList[i].pAvgRating >= 4) && (stack3.arr3[stackTop3].productList[i].pAvgRating <= 5)) {
                                stack3.arr3[stackTop3].productList[i].img = "ratings_star_5.png";
                            }
                            if (stack3.arr3[0].productList[i].saleNote === "                                   On sale!!") {
                                stack3.arr3[0].productList[i].pSalePrice2 = stack3.arr3[0].productList[i].pSalePrice;
                                stack3.arr3[0].productList[i].pSalePrice1 = "";
                            } else {
                                stack3.arr3[0].productList[i].pSalePrice1 = stack3.arr3[0].productList[i].pSalePrice;
                                stack3.arr3[0].productList[i].pSalePrice2 = "";
                            }
                        }
                        frmProd.segCat2.widgetDataMap = {
                            lblPrice: "pSalePrice1",
                            lblPriceRed: "pSalePrice2",
                            lblSaleNote: "saleNote",
                            imgProd: "pImage",
                            lblID: "pId",
                            lblRat: "Tex",
                            imgRating: "img",
                            lblName: "pName"
                        };
                        frmProd.segCat2.setData(stack3.arr3[stackTop3].productList);
                        var w = "page";
                        w = w.concat(stack3.arr3[stackTop3].currentPage);
                        w = w.concat("of");
                        w = w.concat(stack3.arr3[stackTop3].totalPages);
                        frmProd.lblPage.text = w;
                        frmProd.lblPage2.text = w;
                        //	frmProd.lblPage.centerX="50%";
                        //frmProd.lblPage.centeY="93.5%";
                        frmProd.forceLayout();
                        sPageNo = stack3.arr3[stackTop3].currentPage;
                        if (sPageNo === stack3.arr3[stackTop3].totalPages) {
                            frmProd.btnNext.setVisibility(false);
                            //kony.print(stack2.arr2[0].currentPage+"compare in con"+stack2.arr2[0].totalPages);	
                        } else {
                            frmProd.btnNext.setVisibility(true);
                        }
                        if (sPageNo == 1) {
                            frmProd.btnPrev.setVisibility(false);
                        } else {
                            frmProd.btnPrev.setVisibility(true);
                        }
                        frmProd.lblDisp2.text = ("search result for " + mySearch);
                        frmProd.show();
                        frmProd.forceLayout();
                    }
                }
            }
        }
    }
}
/*

        for(i=0;i<stack3.arr3[stackTop3].productList.length;i++)
  		{
         stack3.arr3[stackTop3].productList[i].pSalePrice=dollerSign.concat(stack3.arr3[stackTop3].productList[i].pSalePrice);
          kony.print(i);
         
          stack3.arr3[stackTop3].productList[i].Tex="Rating";
          if((stack3.arr3[stackTop3].productList[i].pAvgReview>=0)&&(stack3.arr3[stackTop3].productList[i].pAvgReview<1))
           {
             stack3.arr3[stackTop3].productList[i].img="ratings_star_1.png";
            
           }
	   		else if((stack3.arr3[stackTop3].productList[i].pAvgReview>=1)&&(stack3.arr3[stackTop3].productList[i].pAvgReview<2)){
              stack3.arr3[stackTop3].productList[i].img="ratings_star_2.png";
            }	
          else if((stack3.arr3[stackTop3].productList[i].pAvgReview>=2)&&(stack3.arr3[stackTop3].productList[i].pAvgReview<3)){
              stack3.arr3[stackTop3].productList[i].img="ratings_star_3.png";
            }
            else if((stack3.arr3[stackTop3].productList[i].pAvgReview>=3)&&(stack3.arr3[stackTop3].productList[i].pAvgReview<4)){
              stack3.arr3[stackTop3].productList[i].img="ratings_star_4.png";
            }
        	else if((stack3.arr3[stackTop3].productList[i].pAvgReview>=4)&&(stack3.arr3[stackTop3].productList[i].pAvgReview<5)){
              stack3.arr3[stackTop3].productList[i].img="ratings_star_5.png";
            }
        }	
        frmProd.segCat2.widgetDataMap={lblID:"pId",lblRat:"Tex",imgProd:"pImage",imgRating:"img",lblName:"pName",lblPrice:"pSalePrice"};         
          frmProd.segCat2.setData(stack3.arr3[stackTop3].productList);
        var w="page"; 
        w=w.concat(stack3.arr3[stackTop3].currentPage);
        w=w.concat("of");
        w=w.concat(stack3.arr3[stackTop3].totalPages);
        frmProd.lblPage.text=w;
        frmProd.lblPage.centerX="50%";
        frmProd.lblPage.centeY="93.5%";
        frmProd.forceLayout(); 
        //var  ImgData=[]
      	if(frm===1)
          {
            var q="";
            q=q.concat("catogories:");
            q=q.concat(hm2[countH]);
            frmProd.lblDisp2.text=q;	
          }
        k=stack3.arr3[stackTop3].currentPage;
        if(k===stack3.arr3[stackTop3].totalPages)
       { 
         frmProd.btnNext.setVisibility(false);
         //kony.print(stack3.arr3[stackTop3].currentPage+"compare in con"+stack3.arr3[stackTop3].totalPages);	
       }
        else
          {
            frmProd.btnNext.setVisibility(true);
          }
         frmProd.btnPrev.setVisibility(false); 
        //kony.print(stack3.arr3[stackTop3].currentPage+"compare "+stack3.arr3[stackTop3].totalPages);
       
        frmProd.show();
              
      }
    else{
      kony.print("44");
       // getProducts(temp);
    }
   }
  }
  else{
    kony.application.dismissLoadingScreen();
    // The call failed because opstatus was not 0 so we'll alert the user and show that opststus
    kony.ui.Alert({ message: "Service call failed with opstatus " + BestBuyResponse.opstatus,alertType:constants. ALERT_TYPE_ERROR, alertTitle:"Best Buy",yesLabel:"OK"}, {});
  }
}
*/