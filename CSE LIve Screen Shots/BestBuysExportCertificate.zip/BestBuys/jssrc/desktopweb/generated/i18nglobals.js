kony.globals["appid"] = "BestBuys";
kony.globals["locales"] = [];