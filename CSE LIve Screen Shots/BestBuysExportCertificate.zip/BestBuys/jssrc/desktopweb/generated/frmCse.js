function addWidgetsfrmCse() {
    frmCse.setDefaultUnit(kony.flex.DP);
    var FlexContainer05cb62b880cf447 = new kony.ui.FlexContainer({
        "autogrowMode": kony.flex.AUTOGROW_NONE,
        "clipBounds": true,
        "height": "902dp",
        "id": "FlexContainer05cb62b880cf447",
        "isVisible": true,
        "layoutType": kony.flex.FREE_FORM,
        "left": "7dp",
        "skin": "CopyslFbox0e1c4556c4b094a",
        "top": "0dp",
        "width": "25.71%",
        "zIndex": 1
    }, {}, {});
    FlexContainer05cb62b880cf447.setDefaultUnit(kony.flex.DP);
    var Calendar007588585828847 = new kony.ui.Calendar({
        "calendarIcon": "calbtn.png",
        "dateComponents": [8, 5, 2017, 0, 0, 0],
        "dateFormat": "dd/MM/yyyy",
        "day": 8,
        "formattedDate": "08/05/2017",
        "height": "50dp",
        "hour": 0,
        "id": "Calendar007588585828847",
        "isVisible": true,
        "left": "40dp",
        "minutes": 0,
        "month": 5,
        "placeholder": "go for time",
        "seconds": 0,
        "skin": "CopyslCalendar02e1db488949541",
        "top": "22%",
        "viewConfig": {},
        "viewType": constants.CALENDAR_VIEW_TYPE_DEFAULT,
        "width": "260dp",
        "year": 2017,
        "zIndex": 1
    }, {
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "noOfMonths": 1,
        "titleOnPopup": "Its calender"
    });
    FlexContainer05cb62b880cf447.add(Calendar007588585828847);
    frmCse.add(FlexContainer05cb62b880cf447);
};

function frmCseGlobals() {
    frmCse = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCse,
        "enabledForIdleTimeout": false,
        "id": "frmCse",
        "layoutType": kony.flex.FREE_FORM,
        "needAppMenu": false,
        "skin": "CopyslForm0da8ddf23b4e944"
    }, {
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "layoutType": kony.flex.FREE_FORM,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false
    });
    frmCse.info = {
        "kuid": "2473e33543c04bf887ae7fbe8e972381"
    };
};