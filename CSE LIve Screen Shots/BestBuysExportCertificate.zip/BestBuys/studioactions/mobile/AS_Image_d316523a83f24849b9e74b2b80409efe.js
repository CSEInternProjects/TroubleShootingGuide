function AS_Image_d316523a83f24849b9e74b2b80409efe(eventobject, x, y) {
    frmProd.flxCon1.setVisibility(true);
    frmProd.flxCon1.zIndex = "4";
    frmProd.tbxSearch.setVisibility(true);
    frmProd.tbxSearch.zIndex = "5";
    frmProd.btnGoSearch.setVisibility(true);
    frmProd.btnGoSearch.zIndex = "5";
    frmProd.forceLayout();
}