function AS_Label_ea15045aa9574a48b5d3807b3b601941(eventobject, x, y) {
    return moveAnimation2.call(this);
}