function AS_Button_87e568fd39a4468fa7db6c595a4a71d1(eventobject) {
    frmCat.flxCon1.zIndex = "1";
    frmCat.flxCon2.zIndex = "1";
    frmCat.flxCon1.setVisibility(false);
    frmCat.tbxSearch.setVisibility(false);
    frmCat.tbxSearch.text = "";
    frmCat.tbxSearch.zIndex = "1";
    frmCat.btnGoSearch.setVisibility(false);
    frmCat.btnGoSearch.zIndex = "1";
    frmCat.flxCon1.lblNoSearch.setVisibility(false);
    frmCat.forceLayout();
}