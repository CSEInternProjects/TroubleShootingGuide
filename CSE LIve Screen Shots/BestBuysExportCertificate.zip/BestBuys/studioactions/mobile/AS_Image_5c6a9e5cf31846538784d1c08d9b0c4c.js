function AS_Image_5c6a9e5cf31846538784d1c08d9b0c4c(eventobject, x, y) {
    return backStack.call(this);
}