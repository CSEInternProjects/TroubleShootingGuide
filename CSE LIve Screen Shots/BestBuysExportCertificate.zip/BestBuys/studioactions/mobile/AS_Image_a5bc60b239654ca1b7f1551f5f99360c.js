function AS_Image_a5bc60b239654ca1b7f1551f5f99360c(eventobject, x, y) {
    return onClickBack3.call(this);
}