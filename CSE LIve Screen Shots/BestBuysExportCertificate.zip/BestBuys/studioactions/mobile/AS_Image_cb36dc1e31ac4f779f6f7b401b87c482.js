function AS_Image_cb36dc1e31ac4f779f6f7b401b87c482(eventobject, x, y) {
    AS_Image_d5c65b684772437d979190f9f175f462(eventobject, x, y);
}