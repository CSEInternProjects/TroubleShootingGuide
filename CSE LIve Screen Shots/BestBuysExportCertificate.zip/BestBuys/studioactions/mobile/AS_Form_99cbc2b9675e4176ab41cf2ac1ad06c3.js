function AS_Form_99cbc2b9675e4176ab41cf2ac1ad06c3(eventobject) {
    scaleAnimation.call(this);
    frmProd.lblPage.centerX = "50%";
    frmProd.lblPage2.centerX = "50%";
    frmProd.lblPage.centerY = "50%";
    frmProd.lblPage2.centerY = "50%";
    frmProd.forceLayout();
}