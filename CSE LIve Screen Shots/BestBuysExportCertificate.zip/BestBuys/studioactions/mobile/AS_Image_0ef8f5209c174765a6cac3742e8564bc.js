function AS_Image_0ef8f5209c174765a6cac3742e8564bc(eventobject, x, y) {
    return frmBack22.call(this);
}