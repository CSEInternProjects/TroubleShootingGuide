function AS_Segment_c6ab25160fdf4c9ea36806df8252f353(eventobject, sectionNumber, rowNumber) {
    return segRowTouch.call(this);
}