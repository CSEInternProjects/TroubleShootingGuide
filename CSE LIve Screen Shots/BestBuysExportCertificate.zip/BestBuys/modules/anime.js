//Type your code here
function scaleAnimation(){
  frmProd.forceLayout();
  var transformObj1 = kony.ui.makeAffineTransform();
  var transformObj2 = kony.ui.makeAffineTransform();
  
    // This will be invoked when you click on translate button
    	transformObj1.scale(0, 0);
    	transformObj2.scale(1, 1);
 
 
  var animationObject = kony.ui.createAnimation(
    {"0":{"anchorPoint":{"x":0.5,"y":0.5},"transform":transformObj1,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
    "100":{"anchorPoint":{"x":0.5,"y":0.5},"transform":transformObj2,"stepConfig":{"timingFunction":kony.anim.LINEAR}}});
   	var animationConfig = {
    	duration: 1,
    	fillMode: kony.anim.FILL_MODE_FORWARDS
    };
  	var animationCallbacks = {"animationEnd":function(){kony.print("animation END");}};
  	var animationDefObject={definition:animationObject,config:animationConfig,callbacks:animationCallbacks};
  	frmProd.forceLayout();
  	frmProd.segCat2.setAnimations({visible:animationDefObject});
  	frmProd.forceLayout();
}
function scrollAnimation(){
  var transformObj1 = kony.ui.makeAffineTransform();
  var transformObj2 = kony.ui.makeAffineTransform();
  
    // This will be invoked when you click on translate button
    	transformObj1.translate(300, 0);
    	transformObj2.translate(0, 0);
 
 
  var animationObject = kony.ui.createAnimation(
    {"0":{"anchorPoint":{"x":0.5,"y":0.5},"transform":transformObj1,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
    "100":{"anchorPoint":{"x":0.5,"y":0.5},"transform":transformObj2,"stepConfig":{"timingFunction":kony.anim.LINEAR}}});
   	var animationConfig = {
    	duration: 1,
    	fillMode: kony.anim.FILL_MODE_FORWARDS
    };
  	var animationCallbacks = {"animationEnd":function(){kony.print("animation END");}};
  	var animationDefObject={definition:animationObject,config:animationConfig,callbacks:animationCallbacks};
  	frmCat.segCat.setAnimations({visible:animationDefObject});
  
}

function stepConfig(){
  var tranformObject = kony.ui.makeAffineTransform();
  tranformObject.rotate3D(90,0,1,0);
  tranformObject.setPerspective(1000);
  var animationStepConfig = kony.ui.createAnimation(
    {
     "100":{"transform":tranformObject,"stepConfig":{"timingFunction":kony.anim.LINEAR}}
    });
  return animationStepConfig;
}
    
    
    
function timingConfig(){
	var animationTimeConfig = {"delay":0,"iterationCount":1,"fillMode":kony.anim.FILL_MODE_FORWARDS,"duration":0.5};
    return animationTimeConfig; 
}
  
function callbackConfig(){
  	var animationCallbackconfig = {"animationEnd":function(){
 
      var transformObject1 = kony.ui.makeAffineTransform();
      transformObject1.rotate3D(90,0,1,0);
      transformObject1.setPerspective(1000);
      
      var transformObject2 = kony.ui.makeAffineTransform();
      transformObject2.rotate3D(0,0,1,0);
      transformObject2.setPerspective(1000);
      
      var animconfig = kony.ui.createAnimation(
      {
        "0":{"transform":transformObject1,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
       "100":{"transform":transformObject2,"stepConfig":{"timingFunction":kony.anim.LINEAR}}
      });
      
      var timingconfig = {"delay":0,"iterationCount":1,"fillMode":kony.anim.FILL_MODE_FORWARDS,"duration":0.5};
      if (currentWidgetType=="image"){
          //frmpro.imgCar.setVisibility(false);
      	  //frmpro.lblCarInfo.setVisibility(true);
      	  //frmpro.lblCarInfo.animate(animconfig,timingconfig, null); 
      	  frmProd.lblPage.setVisibility(false);
      	  frmProd.lblPage2.setVisibility(true);
      	  frmProd.forceLayout();
          frmProd.lblPage2.animate(animconfig,timingconfig, null);
      }
      else{
        //frmpro.lblCarInfo.setVisibility(false);
      	//frmpro.imgCar.setVisibility(true);
      	//frmpro.imgCar.animate(animconfig,timingconfig, null);  
      	frmProd.lblPage2.setVisibility(false);
      	frmProd.lblPage.setVisibility(true);
      	frmProd.forceLayout();
        frmProd.lblPage.animate(animconfig,timingconfig, null);
      }
  	}};
  
    return animationCallbackconfig;
  
} 

widgetType="image";
function animate3D(){
    currentWidgetType=widgetType;
    if(widgetType=="image")
    {
    	//frmpro.lblCarInfo.setVisibility(false);
  		frmProd.lblPage2.setVisibility(false);
      	frmProd.forceLayout();
      	//frmpro.imgCar.animate(stepConfig(), timingConfig(), callbackConfig());
    	frmProd.lblPage.animate(stepConfig(), timingConfig(), callbackConfig());
      	widgetType="heyy";
    }
    else
    {
    	//frmpro.imgCar.setVisibility(false);
  		frmProd.lblPage.setVisibility(false);
      	frmProd.forceLayout();
      	//frmpro.lblCarInfo.animate(stepConfig(), timingConfig(), callbackConfig());
    	frmProd.lblPage2.animate(stepConfig(), timingConfig(), callbackConfig());
      	widgetType="image";
  }
}
function moveAnimation(){
  var transformObj1 = kony.ui.makeAffineTransform();
  var transformObj2 = kony.ui.makeAffineTransform();
  //var transformObj3 = kony.ui.makeAffineTransform();
  //var transformObj4 = kony.ui.makeAffineTransform();
    // This will be invoked when you click on translate button
    	transformObj1.translate(7, -25);
    	transformObj2.translate(7,55);
        //transformObj3.translate(263, -10);
    	//transformObj4.translate(263,70);
 
  var animationObject = kony.ui.createAnimation(
    {"0":{"top":"0%","stepConfig":{"timingFunction":kony.anim.LINEAR}},
    "100":{"top":"10%","stepConfig":{"timingFunction":kony.anim.LINEAR}}});
  //var animationObject2 = kony.ui.createAnimation(
    //{"0":{"transform":transformObj3,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
    //"100":{"transform":transformObj4,"stepConfig":{"timingFunction":kony.anim.LINEAR}}}); 	
  var animationConfig = {
    	duration: 1,
    	fillMode: kony.anim.FILL_MODE_FORWARDS
    };
  
  	//var animationCallbacks = {"animationEnd":function(){kony.print("animation END");}};
  	//var animationDefObject={definition:animationObject,config:animationConfig,callbacks:animationCallbacks};
  	//frmCat.tbxSearch.animate(animationObject,animationConfig, MoveAnimeForGo);
  	frmCat.FlexContainer0dd544890451d43.animate(animationObject,animationConfig, null); 
  // frmCat.btnGoSearch.animate(animationObject2, animationConfig2, null);

}
function MoveAnimeForGo()
{
  kony.print("can write anime");
}
function moveAnimation2(){
  var transformObj1 = kony.ui.makeAffineTransform();
  var transformObj2 = kony.ui.makeAffineTransform();
  //var transformObj3 = kony.ui.makeAffineTransform();
  //var transformObj4 = kony.ui.makeAffineTransform();
    // This will be invoked when you click on translate button
    	transformObj1.translate(7, 55);
    	transformObj2.translate(7,-25);
        //transformObj3.translate(263, -10);
    	//transformObj4.translate(263,70);
 
  var animationObject = kony.ui.createAnimation(
    {"0":{"top":"10%","stepConfig":{"timingFunction":kony.anim.LINEAR}},
    "100":{"top":"0%","stepConfig":{"timingFunction":kony.anim.LINEAR}}});
  //var animationObject2 = kony.ui.createAnimation(
    //{"0":{"transform":transformObj3,"stepConfig":{"timingFunction":kony.anim.LINEAR}},
    //"100":{"transform":transformObj4,"stepConfig":{"timingFunction":kony.anim.LINEAR}}}); 	
  var animationConfig = {
    	duration: 1,
    	fillMode: kony.anim.FILL_MODE_FORWARDS
    };
  
  	//var animationCallbacks = {"animationEnd":function(){kony.print("animation END");}};
  	//var animationDefObject={definition:animationObject,config:animationConfig,callbacks:animationCallbacks};
  	//frmCat.tbxSearch.animate(animationObject,animationConfig, MoveAnimeForGo);
  	frmCat.FlexContainer0dd544890451d43.animate(animationObject,animationConfig, disapperWithTimer()); 
  // frmCat.btnGoSearch.animate(animationObject2, animationConfig2, null);

}

function disappear()  // not using now,instead i am using Timer
{
 // myFunction();
  
 //function myFunction() {
   // setTimeout(function(){ 
    frmCat.flxCon1.zIndex="1";
frmCat.flxCon2.zIndex="1";
frmCat.flxCon1.setVisibility(false);
frmCat.tbxSearch.setVisibility(false);
frmCat.tbxSearch.text="";
frmCat.tbxSearch.zIndex="1";
frmCat.btnGoSearch.setVisibility(false);
frmCat.btnGoSearch.zIndex="1";
frmCat.flxCon1.lblNoSearch.setVisibility(false);
frmCat.forceLayout();
//    }, 1000);
//}
  

}
function timerFunc() //nested function
{
	//i=i+5;
	//lbl1.text = i+" secs ";
/*frmCat.flxCon1.zIndex="1";
frmCat.flxCon2.zIndex="1";
frmCat.flxCon1.setVisibility(false);
frmCat.tbxSearch.setVisibility(false);
frmCat.tbxSearch.text="";
frmCat.tbxSearch.zIndex="1";
frmCat.btnGoSearch.setVisibility(false);
frmCat.btnGoSearch.zIndex="1";
frmCat.flxCon1.lblNoSearch.setVisibility(false);*/
frmCat.flxCon1.setVisibility(false);  
frmCat.flxCon2.setVisibility(false);
frmCat.flxMaster.imgBack.setVisibility(true);  
frmCat.forceLayout();
}
function disapperWithTimer()
{
kony.timer.schedule("mytimer12",timerFunc, 1,false);
}